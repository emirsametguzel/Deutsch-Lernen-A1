        const unitsData = window.unitsData;

        // Current state
        let currentView = 'home';
        let currentUnit = null;
        let currentSection = null;
        let exerciseScores = {};
        let testScores = {};
        let darkMode = false;
        let studentInfo = null;
        let studentDocId = null;
        let isTeacher = false;
        let contentListener = null; // For real-time content updates

        // Initialize app
        async function init() {
            loadProgress();
            loadContentFromFirestore(); // Load dynamic content
            // Always sign out on refresh, but sync progress first (so same name can continue)
            await syncProgressThenClearLogin();
            checkStudentInfo();
            updateStudentDisplay();
            showHome();
            updateGlobalProgress();
            checkCertificateEligibility();
        }

        async function syncProgressThenClearLogin() {
            const previousDocId = localStorage.getItem('studentDocId');
            if (previousDocId && db) {
                try {
                    await updateStudentInFirestoreForDocId(previousDocId);
                } catch (e) {
                    console.warn('⚠️ Progress sync failed before sign-out:', e);
                }
            }

            // Clear "logged in" identity every refresh
            localStorage.removeItem('studentInfo');
            localStorage.removeItem('studentDocId');
            studentInfo = null;
            studentDocId = null;
            isTeacher = false;

            const teacherBtn = document.getElementById('teacherBtn');
            if (teacherBtn) teacherBtn.classList.add('hidden');
        }

        async function updateStudentInFirestoreForDocId(docId) {
            if (!docId || !db) return;
            const completedUnits = Object.keys(testScores).filter(key => testScores[key] > 0).map(Number);
            const totalPoints = Object.values(exerciseScores).reduce((a, b) => a + b, 0);
            const avgScore = completedUnits.length > 0
                ? Math.round(Object.values(testScores).reduce((a, b) => a + b, 0) / completedUnits.length)
                : 0;

            await db.collection('students').doc(docId).update({
                completedUnits: completedUnits,
                totalPoints: totalPoints,
                averageScore: avgScore,
                testScores: testScores,
                exerciseScores: exerciseScores,
                favoriteVocabIds: window.favoriteVocabIds ? Array.from(window.favoriteVocabIds) : [],
                lastUpdated: firebase.firestore.FieldValue.serverTimestamp()
            });
        }

        // Load content from Firestore (real-time listener)
        // Load content from Firestore and convert back from safe format
        function loadContentFromFirestore() {
            if (!db) {
                console.log('ℹ️ Firebase bağlı değil, local data kullanılıyor');
                return;
            }
            
            try {
                // Listen for content changes in real-time
                contentListener = db.collection('content').doc('units')
                    .onSnapshot((doc) => {
                        if (doc.exists) {
                            const firestoreData = doc.data();
                            console.log('📥 Firestore\'dan veri alındı');
                            
                            // Merge Firestore content with local data
                            Object.keys(firestoreData).forEach(unitNum => {
                                if (unitsData[unitNum]) {
                                    const fsUnit = firestoreData[unitNum];
                                    
                                    // Merge basic fields
                                    unitsData[unitNum].title = fsUnit.title || unitsData[unitNum].title;
                                    unitsData[unitNum].subtitle = fsUnit.subtitle || unitsData[unitNum].subtitle;
                                    unitsData[unitNum].color = fsUnit.color || unitsData[unitNum].color;
                                    
                                    // Merge kommunikation
                                    if (fsUnit.kommunikation) {
                                        unitsData[unitNum].kommunikation.skills = fsUnit.kommunikation.skills || unitsData[unitNum].kommunikation.skills;
                                        unitsData[unitNum].kommunikation.examples = fsUnit.kommunikation.examples || unitsData[unitNum].kommunikation.examples;
                                        unitsData[unitNum].kommunikation.prompt = fsUnit.kommunikation.prompt || unitsData[unitNum].kommunikation.prompt;
                                        
                                        // Convert dialogues back if needed
                                        if (fsUnit.kommunikation.dialogues && Array.isArray(fsUnit.kommunikation.dialogues)) {
                                            unitsData[unitNum].kommunikation.dialogues = fsUnit.kommunikation.dialogues.map(d => ({
                                                speaker: d.speaker || '',
                                                text: d.text || ''
                                            }));
                                        }
                                    }
                                    
                                    // Merge wortschatz
                                    if (fsUnit.wortschatz && Array.isArray(fsUnit.wortschatz)) {
                                        unitsData[unitNum].wortschatz = fsUnit.wortschatz;
                                    }
                                    
                                    // Convert grammatik back from Firestore format
                                    if (fsUnit.grammatik && Array.isArray(fsUnit.grammatik)) {
                                        unitsData[unitNum].grammatik = convertGrammatikFromFirestore(fsUnit.grammatik);
                                    }
                                    
                                    console.log(`   ✅ Ünite ${unitNum} güncellendi`);
                                }
                            });
                            
                            console.log('✅ İçerik Firestore\'dan güncellendi');
                            
                            // Refresh current view if needed
                            if (currentView === 'unit' && currentUnit) {
                                showUnit(currentUnit);
                            }
                        } else {
                            console.log('ℹ️ Firestore\'da içerik yok, varsayılan data kullanılıyor');
                        }
                    }, (error) => {
                        console.error('❌ İçerik yükleme hatası:', error);
                    });
            } catch (error) {
                console.error('❌ Firestore listener hatası:', error);
            }
        }

        // Check if student info exists
        function checkStudentInfo() {
            studentInfo = JSON.parse(localStorage.getItem('studentInfo'));
            studentDocId = localStorage.getItem('studentDocId');
            if (!studentInfo) {
                showStudentModal();
            } else {
                // Check if teacher
                if (studentInfo.fullName === "Müge Girgin") {
                    isTeacher = true;
                    document.getElementById('teacherBtn').classList.remove('hidden');
                }
            }

            // Load favorites from Firestore if available
            if (studentDocId && db) {
                loadFavoritesFromFirestore();
            }
        }

        // Show student info modal
        function showStudentModal() {
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.innerHTML = `
                <div class="modal">
                    <h2>👨‍🎓 Öğrenci Bilgileri</h2>
                    <form id="studentForm" onsubmit="saveStudentInfo(event)">
                        <div class="form-group">
                            <label>Ad / Vorname:</label>
                            <input type="text" id="studentFirstName" required>
                        </div>
                        <div class="form-group">
                            <label>Soyad / Nachname:</label>
                            <input type="text" id="studentLastName" required>
                        </div>
                        <div class="form-group">
                            <label>Sınıf / Klasse:</label>
                            <input type="text" id="studentClass" required>
                        </div>
                        <div class="form-group">
                            <label>Okul Numarası / Schulnummer:</label>
                            <input type="text" id="studentNumber" required>
                        </div>
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            Kaydet / Speichern
                        </button>
                    </form>
                </div>
            `;
            document.body.appendChild(modal);
        }

        // Save student info with duplicate check
        async function saveStudentInfo(event) {
            event.preventDefault();
            const firstName = document.getElementById('studentFirstName').value.trim();
            const lastName = document.getElementById('studentLastName').value.trim();
            const className = document.getElementById('studentClass').value.trim();
            const number = document.getElementById('studentNumber').value.trim();
            const fullName = `${firstName} ${lastName}`;
            
            studentInfo = {
                firstName: firstName,
                lastName: lastName,
                fullName: fullName,
                class: className,
                number: number,
                createdAt: new Date().toISOString()
            };
            
            localStorage.setItem('studentInfo', JSON.stringify(studentInfo));
            
            // Check for teacher mode
            if (fullName === "Müge Girgin") {
                isTeacher = true;
                document.getElementById('teacherBtn').classList.remove('hidden');
            }
            
            // Check if student already exists in Firestore
            if (db) {
                try {
                    const existingQuery = await db.collection('students')
                        .where('fullName', '==', fullName)
                        .limit(1)
                        .get();
                    
                    if (!existingQuery.empty) {
                        // Student exists, update their document
                        const existingDoc = existingQuery.docs[0];
                        studentDocId = existingDoc.id;
                        await db.collection('students').doc(studentDocId).update({
                            class: className,
                            number: number,
                            lastUpdated: firebase.firestore.FieldValue.serverTimestamp()
                        });
                        console.log('✅ Mevcut öğrenci güncellendi:', studentDocId);

                        // Load progress from Firestore so user continues
                        const doc = await db.collection('students').doc(studentDocId).get();
                        if (doc.exists) {
                            const data = doc.data() || {};
                            testScores = data.testScores || {};
                            exerciseScores = data.exerciseScores || {};
                            if (Array.isArray(data.favoriteVocabIds)) {
                                window.favoriteVocabIds = new Set(data.favoriteVocabIds.map(String));
                                localStorage.setItem('favoriteVocabIds', JSON.stringify(Array.from(window.favoriteVocabIds)));
                            }
                            saveProgress();
                        }
                    } else {
                        // New student, create document
                        const docRef = await db.collection('students').add({
                            ...studentInfo,
                            completedUnits: [],
                            totalPoints: 0,
                            averageScore: 0,
                            testScores: {},
                            exerciseScores: {},
                            favoriteVocabIds: [],
                            lastUpdated: firebase.firestore.FieldValue.serverTimestamp()
                        });
                        studentDocId = docRef.id;
                        console.log('✅ Yeni öğrenci kaydedildi:', studentDocId);

                        // New account: start fresh locally too
                        testScores = {};
                        exerciseScores = {};
                        saveProgress();
                    }
                    
                    localStorage.setItem('studentDocId', studentDocId);
                    // pull favorites after ID is known (merge if any)
                    loadFavoritesFromFirestore();
                } catch (error) {
                    console.error('❌ Firestore kayıt hatası:', error);
                }
            }
            
            document.querySelector('.modal-overlay').remove();
            updateStudentDisplay();
            updateGlobalProgress();
            checkCertificateEligibility();
        }

        // Update student display in header
        function updateStudentDisplay() {
            const display = document.getElementById('studentInfoDisplay');
            if (studentInfo) {
                display.innerHTML = `
                    <div class="student-info" onclick="editStudentInfo()">
                        👤 ${studentInfo.fullName} | Sınıf: ${studentInfo.class} | No: ${studentInfo.number}
                        ${isTeacher ? '<span class="teacher-badge">ÖĞRETMEN</span>' : ''} ✏️
                    </div>
                `;
            }
        }

        // Edit student info
        function editStudentInfo() {
            showStudentModal();
            if (studentInfo) {
                setTimeout(() => {
                    document.getElementById('studentFirstName').value = studentInfo.firstName || '';
                    document.getElementById('studentLastName').value = studentInfo.lastName || '';
                    document.getElementById('studentClass').value = studentInfo.class;
                    document.getElementById('studentNumber').value = studentInfo.number;
                }, 100);
            }
        }

        // Update student data in Firestore after test completion
        async function updateStudentInFirestore() {
            if (!studentDocId || !db) return;
            
            try {
                const completedUnits = Object.keys(testScores).filter(key => testScores[key] > 0).map(Number);
                const totalPoints = Object.values(exerciseScores).reduce((a, b) => a + b, 0);
                const avgScore = completedUnits.length > 0 
                    ? Math.round(Object.values(testScores).reduce((a, b) => a + b, 0) / completedUnits.length)
                    : 0;
                
                await db.collection('students').doc(studentDocId).update({
                    completedUnits: completedUnits,
                    totalPoints: totalPoints,
                    averageScore: avgScore,
                    testScores: testScores,
                    exerciseScores: exerciseScores,
                    favoriteVocabIds: window.favoriteVocabIds ? Array.from(window.favoriteVocabIds) : [],
                    lastUpdated: firebase.firestore.FieldValue.serverTimestamp()
                });
                
                console.log('✅ Öğrenci verisi güncellendi');
            } catch (error) {
                console.error('❌ Firestore güncelleme hatası:', error);
            }
        }

        // ============================================
        // GERMAN TEXT-TO-SPEECH SYSTEM (de-DE ONLY)
        // Rebuilt from scratch for reliable German pronunciation
        // ============================================
        
        let germanVoice = null;
        let voicesReady = false;
        
        // Initialize German TTS system
        function initGermanTTS() {
            if (!('speechSynthesis' in window)) {
                console.error('❌ Bu tarayıcı SpeechSynthesis desteklemiyor');
                return;
            }
            
            const loadVoices = () => {
                const allVoices = window.speechSynthesis.getVoices();
                if (allVoices.length === 0) return;
                
                console.log('🔍 Mevcut sesler:', allVoices.length);
                
                // STRICT German voice selection - ONLY de-DE or de-* voices
                const germanVoices = allVoices.filter(v => {
                    const lang = v.lang.toLowerCase();
                    // MUST start with 'de' - German language code
                    return lang === 'de-de' || lang === 'de-at' || lang === 'de-ch' || lang.startsWith('de-');
                });
                
                console.log('🇩🇪 Almanca sesler:', germanVoices.length);
                germanVoices.forEach(v => console.log('   -', v.name, '|', v.lang));
                
                if (germanVoices.length > 0) {
                    // Sort by preference: de-DE first, then quality indicators
                    germanVoices.sort((a, b) => {
                        let scoreA = 0, scoreB = 0;
                        const nameA = a.name.toLowerCase();
                        const nameB = b.name.toLowerCase();
                        
                        // Prefer de-DE
                        if (a.lang.toLowerCase() === 'de-de') scoreA += 100;
                        if (b.lang.toLowerCase() === 'de-de') scoreB += 100;
                        
                        // Prefer quality voices
                        const qualityNames = ['anna', 'hedda', 'katja', 'helena', 'stefan', 'google', 'microsoft'];
                        qualityNames.forEach(name => {
                            if (nameA.includes(name)) scoreA += 20;
                            if (nameB.includes(name)) scoreB += 20;
                        });
                        
                        // Prefer local voices
                        if (a.localService) scoreA += 10;
                        if (b.localService) scoreB += 10;
                        
                        return scoreB - scoreA;
                    });
                    
                    germanVoice = germanVoices[0];
                    voicesReady = true;
                    console.log('✅ Seçilen Almanca ses:', germanVoice.name, '|', germanVoice.lang);
                } else {
                    console.warn('⚠️ Almanca ses bulunamadı! Tarayıcı varsayılanı kullanılacak.');
                    voicesReady = true; // Still ready, will use lang attribute fallback
                }
            };
            
            // Load voices immediately if available
            if (window.speechSynthesis.getVoices().length > 0) {
                loadVoices();
            }
            
            // Also listen for voiceschanged event (Chrome needs this)
            window.speechSynthesis.onvoiceschanged = loadVoices;
        }
        
        // Main German speech function
        // Online TTS fallback (free, no key) - best effort
        // Note: This uses an external endpoint; availability can vary by network/browser.
        let _ttsAudioEl = null;
        let _lastTtsUrl = null;
        function playOnlineGermanTTS(text) {
            if (!text || text.trim() === '') return false;
            const q = encodeURIComponent(text.trim());

            // Prefer local PHP proxy (avoids CORS; works on InfinityFree)
            const urlLocal = `tts.php?tl=de-DE&q=${q}`;

            // Try a commonly working endpoint first.
            // If it fails (network/CORS), user will still have local speech if available.
            const urlPrimary = `https://translate.googleapis.com/translate_tts?client=gtx&tl=de&ie=UTF-8&q=${q}`;
            const urlSecondary = `https://translate.google.com/translate_tts?ie=UTF-8&tl=de&client=tw-ob&q=${q}`;

            try {
                if (!_ttsAudioEl) {
                    _ttsAudioEl = new Audio();
                    _ttsAudioEl.preload = 'none';
                }
                // stop any current audio
                _ttsAudioEl.pause();
                _ttsAudioEl.currentTime = 0;

                const tryUrl = (url) => new Promise((resolve, reject) => {
                    _ttsAudioEl.onended = () => resolve(true);
                    _ttsAudioEl.onplay = () => resolve(true);
                    _ttsAudioEl.onerror = () => reject(new Error('audio error'));
                    _ttsAudioEl.src = url;
                    _lastTtsUrl = url;
                    const p = _ttsAudioEl.play();
                    if (p && typeof p.catch === 'function') p.catch(reject);
                });

                return tryUrl(urlLocal)
                    .catch(() => tryUrl(urlPrimary))
                    .catch(() => tryUrl(urlSecondary))
                    .then(() => true)
                    .catch((e) => {
                    console.warn('⚠️ Online TTS çalışmadı:', e);
                    return false;
                });
            } catch (e) {
                console.warn('⚠️ Online TTS hata:', e);
                return false;
            }
        }

        function speakGerman(text) {
            if (!text || text.trim() === '') return;

            // A/B: Try browser SpeechSynthesis first (best offline)
            if ('speechSynthesis' in window) {
                try {
                    // Cancel any ongoing speech first
                    window.speechSynthesis.cancel();

                    // Create new utterance
                    const utterance = new SpeechSynthesisUtterance(text);

                    // FORCE German language
                    utterance.lang = 'de-DE';

                    // A: Use cached German voice if available
                    if (germanVoice) {
                        utterance.voice = germanVoice;
                    }

                    // Speech parameters
                    utterance.rate = 0.9;
                    utterance.pitch = 1.0;
                    utterance.volume = 1.0;

                    let spoke = false;
                    utterance.onstart = () => { spoke = true; };
                    utterance.onerror = async (event) => {
                        console.warn('⚠️ SpeechSynthesis hata, online TTS deneniyor:', event.error);
                        await playOnlineGermanTTS(text);
                    };

                    window.speechSynthesis.speak(utterance);

                    // If voices are missing, some browsers fail silently; fallback after a short delay.
                    setTimeout(async () => {
                        if (!spoke && !germanVoice) {
                            await playOnlineGermanTTS(text);
                        }
                    }, 500);

                    return;
                } catch (e) {
                    console.warn('⚠️ SpeechSynthesis kullanılamadı, online TTS deneniyor:', e);
                    // fall through to online
                }
            }

            // C: Online fallback (works even without German voices)
            playOnlineGermanTTS(text);
        }
        
        // Initialize TTS on page load
        if (typeof window !== 'undefined') {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initGermanTTS);
            } else {
                initGermanTTS();
            }
        }

        // Add audio icon with better handling
        function createAudioIcon(text) {
            return `<span class="audio-icon" onclick="event.stopPropagation(); speakGerman('${text.replace(/'/g, "\\'")}'); this.classList.add('playing'); setTimeout(() => this.classList.remove('playing'), 1000);"></span>`;
        }

        // Show home view
        function showHome() {
            currentView = 'home';
            currentUnit = null;
            currentSection = null;
            updateBreadcrumb();
            
            const mainView = document.getElementById('mainView');
            mainView.innerHTML = `
                <div class="fade-in">
                    <div class="home-search">
                        <div class="home-search-title">🔎 Arama (Ana Sayfa)</div>
                        <div class="home-search-row">
                            <input id="homeSearchInput" class="wortschatz-input" type="text"
                                   placeholder="Kelime / Türkçe / konu ara... (örn: gehen, akşam, Person)"
                                   oninput="updateHomeSearchResults(this.value)" />
                            <button class="btn btn-secondary" onclick="clearHomeSearch()">Temizle</button>
                        </div>
                    </div>

                    <div id="homeUnitsContainer"></div>
                    <div id="homeSearchResultsContainer"></div>
                </div>
            `;

            renderHomeUnitsGrid();
        }

        function renderHomeUnitsGrid(filterText) {
            const q = String(filterText || '').trim().toLowerCase();
            const container = document.getElementById('homeUnitsContainer');
            if (!container) return;

            const html = '<div class="units-grid">' +
                Object.keys(unitsData).filter(unitNum => {
                    if (!q) return true;
                    const unit = unitsData[unitNum];
                    const hay = `${unitNum} ${unit.title} ${unit.subtitle}`.toLowerCase();
                    return hay.includes(q);
                }).map(unitNum => {
                    const unit = unitsData[unitNum];
                    const completed = testScores[unitNum] > 0 ? '✅' : '';
                    return `
                        <div class="unit-card" style="--unit-color: ${unit.color}" onclick="showUnit(${unitNum})">
                            <div class="unit-number">${unitNum}</div>
                            <h2>Themenkreis ${unitNum} ${completed}</h2>
                            <p>${escapeHtml(unit.title)}</p>
                            <small>${escapeHtml(unit.subtitle)}</small>
                        </div>
                    `;
                }).join('') +
            '</div>';

            container.innerHTML = html;
        }

        function clearHomeSearch() {
            const input = document.getElementById('homeSearchInput');
            if (input) input.value = '';
            const res = document.getElementById('homeSearchResultsContainer');
            if (res) res.innerHTML = '';
            renderHomeUnitsGrid();
            if (input) input.focus();
        }

        function updateHomeSearchResults(value) {
            const q = String(value || '').trim().toLowerCase();
            renderHomeUnitsGrid(q);

            const container = document.getElementById('homeSearchResultsContainer');
            if (!container) return;
            if (!q) {
                container.innerHTML = '';
                return;
            }

            // search vocabulary across all units
            const matches = [];
            Object.keys(unitsData).forEach(unitNumStr => {
                const unitNum = Number(unitNumStr);
                const unit = unitsData[unitNum];
                if (!unit || !Array.isArray(unit.wortschatz)) return;
                unit.wortschatz.forEach((w, idx) => {
                    const word = (w && w.word) ? String(w.word) : '';
                    const tr = (w && w.tr) ? String(w.tr) : '';
                    const cat = (w && w.category) ? String(w.category) : 'other';
                    const hay = `${word} ${tr} ${cat} u${unitNum} ${unit.title} ${unit.subtitle}`.toLowerCase();
                    if (hay.includes(q)) {
                        matches.push({ unitNum, idx, word, tr, cat, id: `${unitNum}::${word}` });
                    }
                });
            });

            matches.sort((a, b) => {
                if (a.unitNum !== b.unitNum) return a.unitNum - b.unitNum;
                return a.idx - b.idx;
            });

            const top = matches.slice(0, 80);
            const list = top.map(m => `
                <div class="home-search-item" onclick="jumpToVocabFromHome(${m.unitNum}, '${escapeJs(m.word)}')">
                    <div style="display:flex; align-items:center; gap:0.8rem; min-width:0;">
                        <span class="unit-pill">U${m.unitNum}</span>
                        <div style="min-width:0;">
                            <div class="wortschatz-result-word">${escapeHtml(m.word)}</div>
                            <div class="wortschatz-result-tr">${escapeHtml(m.tr)}</div>
                        </div>
                    </div>
                    <div style="display:flex; align-items:center; gap:0.6rem;">
                        <button class="fav-star-btn" title="Favori ekle/çıkar"
                                onclick="event.stopPropagation(); toggleFavoriteVocab('${escapeJs(m.id)}'); updateHomeSearchResults(document.getElementById('homeSearchInput').value);">
                            ${isFavoriteVocab(m.id) ? '★' : '☆'}
                        </button>
                        <span class="audio-icon" onclick="event.stopPropagation(); speakGerman('${escapeJs(m.word)}'); this.classList.add('playing'); setTimeout(() => this.classList.remove('playing'), 1000);"></span>
                    </div>
                </div>
            `).join('');

            container.innerHTML = `
                <div class="home-search-results">
                    <div class="home-search-results-header">
                        <div><strong>Kelime sonuçları:</strong> ${matches.length}</div>
                        <div style="color: var(--text-secondary); font-size: 0.95rem;">
                            ${matches.length > 80 ? 'İlk 80 gösteriliyor' : ''}
                        </div>
                    </div>
                    <div class="home-search-results-list">
                        ${list || `<div style="padding: 1rem;">Sonuç bulunamadı.</div>`}
                    </div>
                </div>
            `;
        }

        function jumpToVocabFromHome(unitNum, word) {
            showUnit(unitNum);
            // ensure Wortschatz UI state matches this unit and query
            initWortschatzUiState();
            window.wortschatzUiState.unitFilter = Number(unitNum);
            window.wortschatzUiState.category = 'all';
            window.wortschatzUiState.onlyFavorites = false;
            window.wortschatzUiState.query = String(word || '');

            toggleSection('wortschatz');

            // after render, jump to first match (best-effort)
            setTimeout(() => {
                const items = getFilteredWortschatzItems(window.wortschatzUiState);
                const idx = items.findIndex(it => String(it.word).toLowerCase() === String(word).toLowerCase());
                if (idx >= 0) goToFlashcard(idx);
                // keep search filled
                const input = document.getElementById('wortschatzSearchInput');
                if (input) input.value = String(word || '');
            }, 0);
        }

        // Show unit detail
        function showUnit(unitNum) {
            currentView = 'unit';
            currentUnit = unitNum;
            currentSection = null;
            updateBreadcrumb();
            
            const unit = unitsData[unitNum];
            const mainView = document.getElementById('mainView');
            
            mainView.innerHTML = `
                <div class="unit-detail fade-in">
                    <h1 style="color: ${unit.color}">Themenkreis ${unitNum}: ${unit.title}</h1>
                    <p style="font-size: 1.1rem; color: var(--text-secondary)">${unit.subtitle}</p>
                    
                    <div class="sections-grid">
                        <button class="section-btn" style="background: linear-gradient(135deg, #FF6B9D, #F38181)" onclick="toggleSection('kommunikation')">
                            💬 Kommunikation
                        </button>
                        <button class="section-btn" style="background: linear-gradient(135deg, #4ECDC4, #95E1D3)" onclick="toggleSection('wortschatz')">
                            📚 Wortschatz
                        </button>
                        <button class="section-btn" style="background: linear-gradient(135deg, #FFE66D, #FCBAD3)" onclick="toggleSection('grammatik')">
                            📖 Grammatik
                        </button>
                        <button class="section-btn" style="background: linear-gradient(135deg, #AA96DA, #FCBAD3)" onclick="toggleSection('ubungen')">
                            ✏️ Übungen
                        </button>
                        <button class="section-btn" style="background: linear-gradient(135deg, #A8E6CF, #95E1D3)" onclick="toggleSection('test')">
                            ✅ Test
                        </button>
                    </div>
                    
                    <div id="kommunikation-content" class="section-content"></div>
                    <div id="wortschatz-content" class="section-content"></div>
                    <div id="grammatik-content" class="section-content"></div>
                    <div id="ubungen-content" class="section-content"></div>
                    <div id="test-content" class="section-content"></div>
                </div>
            `;
        }

        // Toggle section content
        function toggleSection(section) {
            ['kommunikation', 'wortschatz', 'grammatik', 'ubungen', 'test'].forEach(s => {
                const content = document.getElementById(`${s}-content`);
                if (s !== section) {
                    content.classList.remove('active');
                }
            });
            
            const content = document.getElementById(`${section}-content`);
            const isActive = content.classList.contains('active');
            
            if (isActive) {
                content.classList.remove('active');
                currentSection = null;
            } else {
                content.classList.add('active');
                currentSection = section;
                renderSection(section);
            }
            
            updateBreadcrumb();
        }

        // Render section content - FULL IMPLEMENTATION
        function renderSection(section) {
            const unit = unitsData[currentUnit];
            const content = document.getElementById(`${section}-content`);
            
            if (section === 'kommunikation') {
                const komm = unit.kommunikation;
                content.innerHTML = `
                    <h2>🗣️ Kommunikation</h2>
                    <h3>Lernziele / Öğrenme Hedefleri:</h3>
                    <ul style="font-size: 1.1rem; line-height: 2;">
                        ${komm.skills.map(skill => `<li>${skill}</li>`).join('')}
                    </ul>
                    
                    <h3>Beispiele / Örnekler:</h3>
                    ${komm.examples.map(ex => `
                        <div class="dialogue-box">
                            ${ex} ${createAudioIcon(ex)}
                        </div>
                    `).join('')}
                    
                    <h3>Dialog:</h3>
                    ${komm.dialogues.map(d => `
                        <div class="dialogue-box">
                            <div class="speaker">${d.speaker}:</div>
                            <div>${d.text} ${createAudioIcon(d.text)}</div>
                        </div>
                    `).join('')}
                    
                    <h3>Probieren Sie es selbst! / Kendiniz deneyin!</h3>
                    <p>${komm.prompt}</p>
                    <textarea class="input-field" rows="4" placeholder="Schreiben Sie hier..."></textarea>
                `;
            } else if (section === 'wortschatz') {
                initWortschatzUiState();
                initFavorites();

                const wsState = window.wortschatzUiState;
                const unitFilter = wsState.unitFilter ?? currentUnit;
                const categories = getWortschatzCategories(unitFilter);

                // Store current flashcard index for the selected unit-filter scope
                if (!window.flashcardState) window.flashcardState = {};
                const stateKey = getWortschatzStateKey(unitFilter);
                if (!window.flashcardState[stateKey]) {
                    window.flashcardState[stateKey] = { index: 0, flipped: false };
                }

                const items = getFilteredWortschatzItems(wsState);
                const totalWords = items.length;
                const state = window.flashcardState[stateKey];
                if (state.index >= totalWords) {
                    state.index = 0;
                    state.flipped = false;
                }

                const currentIndex = state.index;
                const currentItem = totalWords > 0 ? items[currentIndex] : null;

                const unitOptions = [
                    `<option value="all"${String(unitFilter) === 'all' ? ' selected' : ''}>Tüm Üniteler</option>`,
                    ...Object.keys(unitsData).map(u => {
                        const selected = String(unitFilter) === String(u) ? ' selected' : '';
                        return `<option value="${u}"${selected}>Themenkreis ${u} - ${unitsData[u].title}</option>`;
                    })
                ].join('');

                const categoryOptions = [
                    `<option value="all"${wsState.category === 'all' ? ' selected' : ''}>Tüm Kategoriler</option>`,
                    ...categories.map(c => `<option value="${c}"${wsState.category === c ? ' selected' : ''}>${c}</option>`)
                ].join('');

                const favToggleClass = wsState.onlyFavorites ? 'fav-toggle active' : 'fav-toggle';

                const toolbarHtml = `
                    <div class="wortschatz-toolbar">
                        <div class="wortschatz-toolbar-row">
                            <input id="wortschatzSearchInput" class="wortschatz-input" type="text" autocomplete="off"
                                   placeholder="Ara... (örn: gehen / ich / Türkçe)" value="${escapeHtml(wsState.query || '')}"
                                   oninput="setWortschatzQuery(this.value)" />
                            <select class="wortschatz-select" onchange="setWortschatzUnitFilter(this.value)">
                                ${unitOptions}
                            </select>
                            <select class="wortschatz-select" onchange="setWortschatzCategory(this.value)">
                                ${categoryOptions}
                            </select>
                            <div class="${favToggleClass}" onclick="toggleWortschatzOnlyFavorites()">
                                ★ Sadece Favoriler
                            </div>
                        </div>
                    </div>
                `;

                const emptyHtml = `
                    <div class="dialogue-box" style="margin-top: 1.5rem;">
                        <strong>Sonuç bulunamadı.</strong><br>
                        Arama/filtreyi değiştirerek tekrar deneyin.
                    </div>
                `;

                const flashcardHtml = currentItem ? `
                    <div class="flashcard-container">
                        <div style="width: 100%; max-width: 420px; display: flex; justify-content: flex-end; margin-bottom: 0.4rem;">
                            <button class="fav-star-btn" title="Favori ekle/çıkar"
                                    onclick="event.stopPropagation(); toggleFavoriteVocab('${escapeJs(currentItem.id)}');">
                                ${isFavoriteVocab(currentItem.id) ? '★' : '☆'}
                            </button>
                        </div>
                        <div class="vocab-card ${state.flipped ? 'flipped' : ''}" id="currentFlashcard" onclick="flipFlashcard()">
                            <div class="vocab-card-inner">
                                <div class="vocab-card-front">
                                    <div class="vocab-word">
                                        ${escapeHtml(currentItem.word)}
                                    </div>
                                    <div style="margin-top: 1rem;">
                                        <span class="audio-icon" onclick="event.stopPropagation(); speakGerman('${escapeJs(currentItem.word)}'); this.classList.add('playing'); setTimeout(() => this.classList.remove('playing'), 1000);"></span>
                                    </div>
                                    <div style="text-align: center; color: var(--text-secondary); margin-top: 1.5rem; font-size: 0.95rem;">
                                        🔄 Çevirmek için karta tıklayın
                                    </div>
                                </div>
                                <div class="vocab-card-back">
                                    <div class="vocab-word" style="font-size: 2rem;">
                                        ${escapeHtml(currentItem.word)}
                                    </div>
                                    <div class="vocab-translation" style="font-size: 1.8rem; color: var(--accent-2); margin: 1rem 0;">
                                        🇹🇷 ${escapeHtml(currentItem.tr)}
                                    </div>
                                    <div style="margin-top: 1rem;">
                                        <span class="audio-icon" onclick="event.stopPropagation(); speakGerman('${escapeJs(currentItem.word)}'); this.classList.add('playing'); setTimeout(() => this.classList.remove('playing'), 1000);"></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="flashcard-nav">
                            <button class="flashcard-nav-btn" onclick="prevFlashcard()" ${currentIndex === 0 ? 'disabled' : ''}>
                                ←
                            </button>
                            <div class="flashcard-counter">
                                ${currentIndex + 1} / ${totalWords}
                            </div>
                            <button class="flashcard-nav-btn" onclick="nextFlashcard()" ${currentIndex === totalWords - 1 ? 'disabled' : ''}>
                                →
                            </button>
                        </div>

                        <div class="flashcard-progress">
                            <div class="flashcard-progress-fill" style="width: ${totalWords ? ((currentIndex + 1) / totalWords) * 100 : 0}%"></div>
                        </div>

                        <div class="flashcard-hint">
                            ← → Okları veya klavye tuşlarını kullanarak gezinin
                        </div>
                    </div>
                ` : emptyHtml;

                const resultsPreview = items.slice(0, 60).map((it, idx) => `
                    <div class="wortschatz-result-item" onclick="goToFlashcard(${idx})">
                        <div class="wortschatz-result-left">
                            <button class="fav-star-btn" title="Favori ekle/çıkar"
                                    onclick="event.stopPropagation(); toggleFavoriteVocab('${escapeJs(it.id)}'); renderSection('wortschatz');">
                                ${isFavoriteVocab(it.id) ? '★' : '☆'}
                            </button>
                            <div style="display:flex; flex-direction:column; min-width:0;">
                                <div class="wortschatz-result-word">${escapeHtml(it.word)}</div>
                                <div class="wortschatz-result-tr">${escapeHtml(it.tr)}</div>
                            </div>
                        </div>
                        <div style="display:flex; align-items:center; gap:0.6rem;">
                            <span class="unit-pill">U${it.unitNum}</span>
                            <span class="audio-icon" onclick="event.stopPropagation(); speakGerman('${escapeJs(it.word)}'); this.classList.add('playing'); setTimeout(() => this.classList.remove('playing'), 1000);"></span>
                        </div>
                    </div>
                `).join('');

                const resultsHtml = `
                    <div class="wortschatz-results">
                        <div class="wortschatz-results-header">
                            <div><strong>Sonuçlar:</strong> ${totalWords} kelime</div>
                            <div style="color: var(--text-secondary); font-size: 0.95rem;">
                                ${totalWords > 60 ? `İlk 60 gösteriliyor` : ` `}
                            </div>
                        </div>
                        <div class="wortschatz-results-list">
                            ${resultsPreview || `<div style="padding: 1rem;">${emptyHtml}</div>`}
                        </div>
                    </div>
                `;

                content.innerHTML = `
                    <h2>📚 Wortschatz / Kelime Hazinesi</h2>
                    ${toolbarHtml}
                    ${flashcardHtml}
                    ${resultsHtml}
                `;
                
                // Add keyboard navigation
                document.onkeydown = function(e) {
                    if (currentSection === 'wortschatz') {
                        if (e.key === 'ArrowLeft') prevFlashcard();
                        else if (e.key === 'ArrowRight') nextFlashcard();
                        else if (e.key === ' ' || e.key === 'Enter') flipFlashcard();
                    }
                };
            } else if (section === 'grammatik') {
                content.innerHTML = `
                    <h2>📖 Grammatik / Dilbilgisi</h2>
                    ${unit.grammatik.map((gram, idx) => `
                        <div style="margin: 2rem 0;">
                            <h3 style="color: ${unit.color}">${idx + 1}. ${gram.topic}</h3>
                            <p style="font-size: 1.1rem; line-height: 1.8;">${gram.explanation}</p>
                            
                            <table class="grammar-table">
                                ${gram.table.map((row, rowIdx) => `
                                    <tr>
                                        ${row.map(cell => 
                                            rowIdx === 0 ? `<th>${cell}</th>` : `<td>${cell}</td>`
                                        ).join('')}
                                    </tr>
                                `).join('')}
                            </table>
                            
                            <div class="dialogue-box">
                                <strong>Beispiel / Örnek:</strong><br>
                                ${gram.example} ${createAudioIcon(gram.example)}
                            </div>
                            
                            <h4>Mini-Übung:</h4>
                            <input type="text" class="input-field" placeholder="Schreiben Sie einen Beispielsatz...">
                        </div>
                    `).join('')}
                `;
            } else if (section === 'ubungen') {
                renderEnhancedExercises(content);
            } else if (section === 'test') {
                renderTest(content);
            }
        }

        // Render exercises
        function renderExercises(content) {
            const exercises = generateExercises(currentUnit);
            let score = exerciseScores[currentUnit] || 0;
            
            content.innerHTML = `
                <h2>✏️ Übungen / Alıştırmalar</h2>
                <div class="score-display" id="exerciseScore">Puan / Points: ${score}</div>
                <div id="exercisesContainer"></div>
            `;
            
            const container = document.getElementById('exercisesContainer');
            exercises.forEach((ex, idx) => {
                container.innerHTML += `
                    <div class="exercise-container">
                        <div class="exercise-question">
                            ${idx + 1}. ${ex.question}
                        </div>
                        <div class="exercise-options">
                            ${ex.options.map((opt, optIdx) => `
                                <button class="option-btn" onclick="checkAnswer(${currentUnit}, ${idx}, ${optIdx}, ${ex.correct})" id="ex${idx}-opt${optIdx}">
                                    ${opt}
                                </button>
                            `).join('')}
                        </div>
                    </div>
                `;
            });
        }

        // Generate exercises from unit data
        function generateExercises(unitNum) {
            const unit = unitsData[unitNum];
            const exercises = [];
            
            // Generate 10 exercises from vocabulary
            const vocabSample = unit.wortschatz.sort(() => 0.5 - Math.random()).slice(0, 10);
            
            vocabSample.forEach(word => {
                const wrongAnswers = unit.wortschatz
                    .filter(w => w.word !== word.word)
                    .sort(() => 0.5 - Math.random())
                    .slice(0, 3)
                    .map(w => w.tr);
                
                const options = [word.tr, ...wrongAnswers].sort(() => 0.5 - Math.random());
                
                exercises.push({
                    question: `"${word.word}" ne anlama gelir?`,
                    options: options,
                    correct: options.indexOf(word.tr)
                });
            });
            
            return exercises;
        }

        // Check answer
        function checkAnswer(unitNum, exerciseIdx, selectedIdx, correctIdx) {
            const buttons = document.querySelectorAll(`#ex${exerciseIdx}-opt0, #ex${exerciseIdx}-opt1, #ex${exerciseIdx}-opt2, #ex${exerciseIdx}-opt3`);
            
            buttons.forEach((btn, idx) => {
                btn.disabled = true;
                if (idx === correctIdx) {
                    btn.classList.add('correct');
                } else if (idx === selectedIdx) {
                    btn.classList.add('wrong');
                }
            });
            
            if (selectedIdx === correctIdx) {
                exerciseScores[unitNum] = (exerciseScores[unitNum] || 0) + 1;
                document.getElementById('exerciseScore').textContent = `Puan / Points: ${exerciseScores[unitNum]}`;
                saveProgress();
                updateStudentInFirestore();
            }
        }

        // Render test
        function renderTest(content) {
            const questions = generateTestQuestions(currentUnit);
            
            content.innerHTML = `
                <h2>✅ Test - Themenkreis ${currentUnit}</h2>
                <p style="font-size: 1.1rem;">10 soruyu cevaplayın / Answer 10 questions</p>
                <div id="testContainer"></div>
                <button class="btn btn-primary" style="margin-top: 2rem; width: 100%;" onclick="submitTest()">
                    Testi Gönder / Submit Test
                </button>
            `;
            
            const container = document.getElementById('testContainer');
            questions.forEach((q, idx) => {
                container.innerHTML += `
                    <div class="exercise-container">
                        <div class="exercise-question">${idx + 1}. ${q.question}</div>
                        <div class="exercise-options">
                            ${q.options.map((opt, optIdx) => `
                                <button class="option-btn" onclick="selectTestAnswer(${idx}, ${optIdx})" id="test${idx}-opt${optIdx}">
                                    ${opt}
                                </button>
                            `).join('')}
                        </div>
                    </div>
                `;
            });
            
            window.currentTestQuestions = questions;
            window.testAnswers = [];
        }

        // Generate test questions
        function generateTestQuestions(unitNum) {
            const unit = unitsData[unitNum];
            const questions = [];
            
            // 10 random vocabulary questions
            const vocabSample = unit.wortschatz.sort(() => 0.5 - Math.random()).slice(0, 10);
            
            vocabSample.forEach(word => {
                const wrongAnswers = unit.wortschatz
                    .filter(w => w.word !== word.word)
                    .sort(() => 0.5 - Math.random())
                    .slice(0, 3)
                    .map(w => w.tr);
                
                const options = [word.tr, ...wrongAnswers].sort(() => 0.5 - Math.random());
                
                questions.push({
                    question: `"${word.word}" kelimesinin Almanca karşılığı nedir?`,
                    options: options,
                    correct: options.indexOf(word.tr)
                });
            });
            
            return questions;
        }

        // Select test answer
        function selectTestAnswer(questionIdx, optionIdx) {
            for (let i = 0; i < 4; i++) {
                const btn = document.getElementById(`test${questionIdx}-opt${i}`);
                if (btn) {
                    btn.style.background = 'var(--card-bg)';
                    btn.style.color = 'var(--text-primary)';
                }
            }
            
            const btn = document.getElementById(`test${questionIdx}-opt${optionIdx}`);
            btn.style.background = 'var(--accent-2)';
            btn.style.color = 'white';
            
            window.testAnswers[questionIdx] = optionIdx;
        }

        // Submit test
        async function submitTest() {
            const questions = window.currentTestQuestions;
            let correct = 0;
            
            questions.forEach((q, idx) => {
                if (window.testAnswers[idx] === q.correct) {
                    correct++;
                }
            });
            
            const percentage = Math.round((correct / questions.length) * 100);
            testScores[currentUnit] = percentage;
            saveProgress();
            await updateStudentInFirestore();
            updateGlobalProgress();
            checkCertificateEligibility();
            
            const messages = {
                100: "Perfekt! / Mükemmel! 🌟",
                80: "Sehr gut! / Çok iyi! 🎉",
                60: "Gut! / İyi! 👍",
                40: "Üben! / Pratik yap! 💪",
                0: "Versuchen Sie es noch einmal! / Tekrar dene! 🌱"
            };
            
            let message = messages[0];
            for (let threshold in messages) {
                if (percentage >= threshold) {
                    message = messages[threshold];
                    break;
                }
            }
            
            const content = document.getElementById('test-content');
            content.innerHTML = `
                <div class="test-result fade-in">
                    <h2>Test Sonucu / Test Result</h2>
                    <div class="test-score">${percentage}%</div>
                    <div class="motivational-message">${message}</div>
                    <p style="font-size: 1.2rem;">
                        ${correct} / ${questions.length} doğru
                    </p>
                    <button class="btn btn-primary" onclick="toggleSection('test')" style="margin-top: 2rem;">
                        Tekrar dene / Try again
                    </button>
                </div>
            `;
        }

        // Filter vocabulary (legacy - kept for compatibility)
        function filterVocab(searchTerm) {
            const cards = document.querySelectorAll('.vocab-card');
            cards.forEach(card => {
                const text = card.textContent.toLowerCase();
                if (text.includes(searchTerm.toLowerCase())) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Filter by category (legacy - kept for compatibility)
        function filterByCategory(category, event) {
            const cards = document.querySelectorAll('.vocab-card');
            const buttons = document.querySelectorAll('.filter-btn');
            
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            cards.forEach(card => {
                if (category === 'all' || card.dataset.category === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Flip vocabulary card (legacy)
        function flipCard(cardIdx) {
            const cards = document.querySelectorAll('.vocab-card');
            cards[cardIdx].classList.toggle('flipped');
        }

        // ============================================
        // NEW FLASHCARD SYSTEM
        // ============================================

        // ============================================
        // WORTSCHATZ: SEARCH / FILTER / FAVORITES
        // ============================================

        function initWortschatzUiState() {
            if (!window.wortschatzUiState) {
                window.wortschatzUiState = {
                    unitFilter: currentUnit,
                    category: 'all',
                    query: '',
                    onlyFavorites: false
                };
            } else if (window.wortschatzUiState.unitFilter == null) {
                window.wortschatzUiState.unitFilter = currentUnit;
            }
        }

        function getWortschatzStateKey(unitFilter) {
            return `ws:${unitFilter ?? currentUnit}`;
        }

        function escapeHtml(str) {
            return String(str ?? '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function escapeJs(str) {
            return String(str ?? '')
                .replace(/\\/g, '\\\\')
                .replace(/'/g, "\\'")
                .replace(/\n/g, '\\n')
                .replace(/\r/g, '\\r');
        }

        function initFavorites() {
            if (window.favoriteVocabIds) return;
            try {
                const raw = localStorage.getItem('favoriteVocabIds');
                const arr = raw ? JSON.parse(raw) : [];
                window.favoriteVocabIds = new Set(Array.isArray(arr) ? arr : []);
            } catch {
                window.favoriteVocabIds = new Set();
            }
        }

        function saveFavorites() {
            if (!window.favoriteVocabIds) return;
            try {
                localStorage.setItem('favoriteVocabIds', JSON.stringify(Array.from(window.favoriteVocabIds)));
            } catch (e) {
                console.warn('⚠️ Favoriler kaydedilemedi:', e);
            }
            updateFavoritesInFirestoreDebounced();
        }

        let _favoritesSyncTimer = null;
        function updateFavoritesInFirestoreDebounced() {
            if (!db || !studentDocId) return;
            if (_favoritesSyncTimer) clearTimeout(_favoritesSyncTimer);
            _favoritesSyncTimer = setTimeout(async () => {
                try {
                    initFavorites();
                    await db.collection('students').doc(studentDocId).update({
                        favoriteVocabIds: Array.from(window.favoriteVocabIds),
                        lastUpdated: firebase.firestore.FieldValue.serverTimestamp()
                    });
                } catch (e) {
                    console.warn('⚠️ Favoriler Firestore güncellenemedi:', e);
                }
            }, 600);
        }

        async function loadFavoritesFromFirestore() {
            if (!db || !studentDocId) return;
            try {
                initFavorites();
                const doc = await db.collection('students').doc(studentDocId).get();
                if (!doc.exists) return;
                const data = doc.data() || {};
                const arr = Array.isArray(data.favoriteVocabIds) ? data.favoriteVocabIds : [];
                // Merge: keep local favorites too
                arr.forEach(id => window.favoriteVocabIds.add(String(id)));
                saveFavorites(); // persists merged result and schedules Firestore update
            } catch (e) {
                console.warn('⚠️ Favoriler Firestore’dan okunamadı:', e);
            }
        }

        function isFavoriteVocab(id) {
            initFavorites();
            return window.favoriteVocabIds.has(id);
        }

        function toggleFavoriteVocab(id) {
            initFavorites();
            if (window.favoriteVocabIds.has(id)) window.favoriteVocabIds.delete(id);
            else window.favoriteVocabIds.add(id);
            saveFavorites();
        }

        let _wsQueryTimer = null;
        function setWortschatzQuery(value) {
            initWortschatzUiState();
            const input = document.getElementById('wortschatzSearchInput');
            const selStart = input && typeof input.selectionStart === 'number' ? input.selectionStart : null;
            const selEnd = input && typeof input.selectionEnd === 'number' ? input.selectionEnd : null;

            window.wortschatzUiState.query = value ?? '';
            const stateKey = getWortschatzStateKey(window.wortschatzUiState.unitFilter);
            if (window.flashcardState && window.flashcardState[stateKey]) {
                window.flashcardState[stateKey].index = 0;
                window.flashcardState[stateKey].flipped = false;
            }

            if (_wsQueryTimer) clearTimeout(_wsQueryTimer);
            _wsQueryTimer = setTimeout(() => {
                renderSection('wortschatz');
                // restore focus after rerender (prevents "re-click each char" issue)
                requestAnimationFrame(() => {
                    const nextInput = document.getElementById('wortschatzSearchInput');
                    if (nextInput) {
                        nextInput.focus();
                        if (selStart != null && selEnd != null) {
                            try { nextInput.setSelectionRange(selStart, selEnd); } catch {}
                        }
                    }
                });
            }, 120);
        }

        function setWortschatzCategory(value) {
            initWortschatzUiState();
            window.wortschatzUiState.category = value || 'all';
            const stateKey = getWortschatzStateKey(window.wortschatzUiState.unitFilter);
            if (window.flashcardState && window.flashcardState[stateKey]) {
                window.flashcardState[stateKey].index = 0;
                window.flashcardState[stateKey].flipped = false;
            }
            renderSection('wortschatz');
        }

        function setWortschatzUnitFilter(value) {
            initWortschatzUiState();
            window.wortschatzUiState.unitFilter = (value === 'all') ? 'all' : Number(value);
            window.wortschatzUiState.category = 'all';
            const stateKey = getWortschatzStateKey(window.wortschatzUiState.unitFilter);
            if (!window.flashcardState) window.flashcardState = {};
            if (!window.flashcardState[stateKey]) {
                window.flashcardState[stateKey] = { index: 0, flipped: false };
            } else {
                window.flashcardState[stateKey].index = 0;
                window.flashcardState[stateKey].flipped = false;
            }
            renderSection('wortschatz');
        }

        function toggleWortschatzOnlyFavorites() {
            initWortschatzUiState();
            window.wortschatzUiState.onlyFavorites = !window.wortschatzUiState.onlyFavorites;
            const stateKey = getWortschatzStateKey(window.wortschatzUiState.unitFilter);
            if (window.flashcardState && window.flashcardState[stateKey]) {
                window.flashcardState[stateKey].index = 0;
                window.flashcardState[stateKey].flipped = false;
            }
            renderSection('wortschatz');
        }

        function getWortschatzCategories(unitFilter) {
            const cats = new Set();
            const unitNums = (unitFilter === 'all')
                ? Object.keys(unitsData).map(Number)
                : [Number(unitFilter ?? currentUnit)];

            unitNums.forEach(u => {
                const unit = unitsData[u];
                if (!unit || !Array.isArray(unit.wortschatz)) return;
                unit.wortschatz.forEach(w => {
                    const c = (w && w.category) ? String(w.category) : 'other';
                    cats.add(c);
                });
            });

            return Array.from(cats).sort((a, b) => a.localeCompare(b));
        }

        function getFilteredWortschatzItems(wsState) {
            initWortschatzUiState();
            initFavorites();

            const unitFilter = wsState.unitFilter ?? currentUnit;
            const unitNums = (unitFilter === 'all')
                ? Object.keys(unitsData).map(Number)
                : [Number(unitFilter)];

            const q = String(wsState.query || '').trim().toLowerCase();
            const category = wsState.category || 'all';
            const onlyFav = !!wsState.onlyFavorites;

            const items = [];
            unitNums.forEach(unitNum => {
                const unit = unitsData[unitNum];
                if (!unit || !Array.isArray(unit.wortschatz)) return;
                unit.wortschatz.forEach((w, idx) => {
                    const word = (w && w.word) ? String(w.word) : '';
                    const tr = (w && w.tr) ? String(w.tr) : '';
                    const cat = (w && w.category) ? String(w.category) : 'other';
                    const id = `${unitNum}::${word}`;

                    if (category !== 'all' && cat !== category) return;
                    if (onlyFav && !window.favoriteVocabIds.has(id)) return;
                    if (q) {
                        const hay = `${word} ${tr} ${cat} u${unitNum}`.toLowerCase();
                        if (!hay.includes(q)) return;
                    }

                    items.push({ id, unitNum, index: idx, word, tr, category: cat });
                });
            });

            items.sort((a, b) => {
                if (a.unitNum !== b.unitNum) return a.unitNum - b.unitNum;
                return a.index - b.index;
            });

            return items;
        }
        
        // Flip current flashcard
        function flipFlashcard() {
            const card = document.getElementById('currentFlashcard');
            if (card) {
                card.classList.toggle('flipped');
                if (window.flashcardState && window.flashcardState[currentUnit]) {
                    window.flashcardState[currentUnit].flipped = card.classList.contains('flipped');
                }
            }
        }
        
        // Go to next flashcard
        function nextFlashcard() {
            if (!currentUnit || !window.flashcardState) return;
            
            initWortschatzUiState();
            const stateKey = getWortschatzStateKey(window.wortschatzUiState.unitFilter ?? currentUnit);
            const totalWords = getFilteredWortschatzItems(window.wortschatzUiState).length;
            const state = window.flashcardState[stateKey];
            if (!state) return;
            
            if (state.index < totalWords - 1) {
                state.index++;
                state.flipped = false;
                renderSection('wortschatz');
            }
        }
        
        // Go to previous flashcard
        function prevFlashcard() {
            if (!currentUnit || !window.flashcardState) return;
            
            initWortschatzUiState();
            const stateKey = getWortschatzStateKey(window.wortschatzUiState.unitFilter ?? currentUnit);
            const state = window.flashcardState[stateKey];
            if (!state) return;
            
            if (state.index > 0) {
                state.index--;
                state.flipped = false;
                renderSection('wortschatz');
            }
        }
        
        // Go to specific flashcard
        function goToFlashcard(index) {
            if (!currentUnit || !window.flashcardState) return;
            
            initWortschatzUiState();
            const stateKey = getWortschatzStateKey(window.wortschatzUiState.unitFilter ?? currentUnit);
            const totalWords = getFilteredWortschatzItems(window.wortschatzUiState).length;
            
            if (index >= 0 && index < totalWords) {
                if (!window.flashcardState[stateKey]) {
                    window.flashcardState[stateKey] = { index: 0, flipped: false };
                }
                window.flashcardState[stateKey].index = index;
                window.flashcardState[stateKey].flipped = false;
                renderSection('wortschatz');
            }
        }

        // Show leaderboard with real-time Firebase data
        async function showLeaderboard() {
            currentView = 'leaderboard';
            updateBreadcrumb();
            
            const mainView = document.getElementById('mainView');
            mainView.innerHTML = `
                <div class="unit-detail fade-in">
                    <h1 style="color: var(--accent-1)">🏆 Global Leaderboard</h1>
                    <p style="font-size: 1.1rem; color: var(--text-secondary); margin-bottom: 2rem;">
                        Tüm öğrencilerin canlı sıralaması
                    </p>
                    <div class="loading">Veriler yükleniyor</div>
                </div>
            `;
            
            if (!db) {
                mainView.innerHTML = `
                    <div class="unit-detail fade-in">
                        <h1>🏆 Leaderboard</h1>
                        <div class="dialogue-box">
                            <strong>⚠️ Firebase bağlantısı yapılandırılmamış!</strong>
                        </div>
                    </div>
                `;
                return;
            }
            
            try {
                // Real-time listener
                db.collection('students')
                    .orderBy('totalPoints', 'desc')
                    .onSnapshot((snapshot) => {
                        const students = [];
                        snapshot.forEach((doc) => {
                            const data = doc.data();
                            // Exclude teacher from leaderboard
                            if (data.fullName !== 'Müge Girgin') {
                                students.push({ id: doc.id, ...data });
                            }
                        });
                        
                        renderLeaderboard(students);
                    });
            } catch (error) {
                console.error('❌ Leaderboard yüklenemedi:', error);
                mainView.innerHTML += `<div class="dialogue-box"><strong>❌ Hata:</strong> ${error.message}</div>`;
            }
        }

        // Render leaderboard table
        function renderLeaderboard(students) {
            const mainView = document.getElementById('mainView');
            
            mainView.innerHTML = `
                <div class="unit-detail fade-in">
                    <h1 style="color: var(--accent-1)">🏆 Global Leaderboard</h1>
                    <p style="font-size: 1.1rem; color: var(--text-secondary); margin-bottom: 2rem;">
                        Toplam ${students.length} öğrenci
                    </p>
                    
                    <table class="leaderboard-table">
                        <thead>
                            <tr>
                                <th>Sıra</th>
                                <th>Ad Soyad</th>
                                <th>Sınıf</th>
                                <th>No</th>
                                <th>Ünite</th>
                                <th>Ort. %</th>
                                <th>Puan</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${students.map((student, index) => {
                                const rank = index + 1;
                                const rankClass = rank === 1 ? 'rank-1' : rank === 2 ? 'rank-2' : rank === 3 ? 'rank-3' : 'rank-other';
                                const isCurrentUser = student.id === studentDocId;
                                
                                return `
                                    <tr style="${isCurrentUser ? 'background: rgba(78, 205, 196, 0.2); font-weight: bold;' : ''}">
                                        <td>
                                            <span class="rank-badge ${rankClass}">${rank}</span>
                                        </td>
                                        <td>${student.fullName} ${isCurrentUser ? '👤' : ''}</td>
                                        <td>${student.class}</td>
                                        <td>${student.number}</td>
                                        <td>${(student.completedUnits || []).length} / 8</td>
                                        <td>${student.averageScore || 0}%</td>
                                        <td><strong>${student.totalPoints || 0}</strong></td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                    
                    <button class="btn btn-secondary" onclick="showHome()" style="margin-top: 2rem;">
                        🏠 Ana Sayfa
                    </button>
                </div>
            `;
        }

        // Show profile
        function showProfile() {
            currentView = 'profile';
            updateBreadcrumb();
            
            if (!studentInfo) {
                alert('Lütfen önce öğrenci bilgilerinizi girin!');
                return;
            }
            
            const completedUnits = Object.keys(testScores).filter(key => testScores[key] > 0).length;
            const totalPoints = Object.values(exerciseScores).reduce((a, b) => a + b, 0);
            const avgScore = completedUnits > 0 
                ? Math.round(Object.values(testScores).reduce((a, b) => a + b, 0) / completedUnits)
                : 0;
            
            const badges = calculateBadges(completedUnits, avgScore, totalPoints);
            
            const mainView = document.getElementById('mainView');
            mainView.innerHTML = `
                <div class="fade-in">
                    <div class="profile-header">
                        <div class="profile-avatar">👨‍🎓</div>
                        <h1>${studentInfo.fullName}</h1>
                        <p style="font-size: 1.2rem; margin-top: 0.5rem;">
                            Sınıf: ${studentInfo.class} | Numara: ${studentInfo.number}
                        </p>
                    </div>
                    
                    <div class="profile-stats">
                        <div class="stat-card">
                            <div class="stat-value">${completedUnits}</div>
                            <div class="stat-label">Tamamlanan Ünite</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${avgScore}%</div>
                            <div class="stat-label">Ortalama Başarı</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${totalPoints}</div>
                            <div class="stat-label">Toplam Puan</div>
                        </div>
                    </div>
                    
                    <div class="unit-detail">
                        <h2>🏅 Rozetler</h2>
                        <div class="badge-container">
                            ${badges.map(badge => `
                                <div class="badge ${badge.unlocked ? '' : 'locked'}" onclick='showBadgeModal(${JSON.stringify(badge)})' style="cursor: pointer;">
                                    <div class="badge-icon">${badge.icon}</div>
                                    <div class="badge-title">${badge.title}</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="unit-detail">
                        <h2>📚 Ünite Detayları</h2>
                        ${Object.keys(unitsData).map(unitNum => {
                            const unit = unitsData[unitNum];
                            const testScore = testScores[unitNum] || 0;
                            const exerciseScore = exerciseScores[unitNum] || 0;
                            const completed = testScore > 0;
                            return `
                                <div class="dialogue-box" style="margin: 1rem 0;">
                                    <h3 style="color: ${unit.color}">
                                        ${completed ? '✅' : '⏳'} Themenkreis ${unitNum}: ${unit.title}
                                    </h3>
                                    <p>Test Sonucu: <strong>${testScore}%</strong></p>
                                    <p>Alıştırma Puanı: <strong>${exerciseScore}</strong></p>
                                </div>
                            `;
                        }).join('')}
                    </div>
                    
                    <div style="text-align: center; margin-top: 2rem;">
                        ${avgScore >= 60 && completedUnits === 8 ? `
                            <button class="btn btn-gold" onclick="showCertificate()" style="font-size: 1.2rem; padding: 1rem 2rem;">
                                🎓 Sertifika Oluştur
                            </button>
                        ` : `
                            <div class="dialogue-box">
                                <strong>ℹ️ Sertifika Koşulları:</strong><br>
                                - Tüm 8 üniteyi tamamlayın (${completedUnits}/8)<br>
                                - En az %60 ortalama başarı (${avgScore}%/60%)
                            </div>
                        `}
                        <br>
                        <button class="btn btn-secondary" onclick="showHome()" style="margin-top: 1rem;">
                            🏠 Ana Sayfa
                        </button>
                        <br>
                        <button class="delete-account-btn" onclick="deleteMyAccount()">
                            🗑️ Hesabımı Sil / Delete Account
                        </button>
                    </div>
                </div>
            `;
        }

        // Check certificate eligibility
        function checkCertificateEligibility() {
            const totalUnits = Object.keys(unitsData).length;
            const completedTests = Object.keys(testScores).filter(key => testScores[key] > 0).length;
            const avgScore = completedTests > 0 
                ? Object.values(testScores).reduce((a, b) => a + b, 0) / completedTests
                : 0;
            
            const certBtn = document.getElementById('certificateBtn');
            if (completedTests === totalUnits && avgScore >= 60) {
                certBtn.classList.remove('hidden');
            } else {
                certBtn.classList.add('hidden');
            }
        }

        // Show certificate
        function showCertificate() {
            currentView = 'certificate';
            updateBreadcrumb();
            
            const completedTests = Object.keys(testScores).filter(key => testScores[key] > 0).length;
            const avgScore = completedTests > 0 
                ? Math.round(Object.values(testScores).reduce((a, b) => a + b, 0) / completedTests)
                : 0;
            const date = new Date().toLocaleDateString('tr-TR');
            
            const mainView = document.getElementById('mainView');
            mainView.innerHTML = `
                <div class="certificate fade-in">
                    <div class="ornament">🏆</div>
                    <h1>German A1 Certificate</h1>
                    <h2>Deutschzertifikat A1</h2>
                    
                    <p style="font-size: 1.3rem; margin: 2rem 0;">
                        Bu belge şunu onaylar ki
                    </p>
                    
                    <div class="student-name">${studentInfo.fullName}</div>
                    
                    <div class="details">
                        <p><strong>Sınıf:</strong> ${studentInfo.class}</p>
                        <p><strong>Numara:</strong> ${studentInfo.number}</p>
                        <p><strong>Tarih:</strong> ${date}</p>
                        <p><strong>Başarı:</strong> ${avgScore}%</p>
                    </div>
                    
                    <p style="font-size: 1.2rem; margin: 2rem 0;">
                        Almanca A1 kursunun 8 ünitesini başarıyla tamamlamıştır.
                    </p>
                    
                    <div class="signature">
                        🎓 Deutsch Lernen A1 Platform
                    </div>
                    
                    <div style="margin-top: 3rem; display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                        <button class="btn btn-primary" onclick="window.print()">
                            🖨️ Yazdır / PDF
                        </button>
                        <button class="btn btn-secondary" onclick="showHome()">
                            🏠 Ana Sayfa
                        </button>
                    </div>
                </div>
            `;
        }

        // TEACHER PANEL
        function showTeacherPanel() {
            if (!isTeacher) return;
            
            currentView = 'teacher';
            updateBreadcrumb();
            
            const mainView = document.getElementById('mainView');
            mainView.innerHTML = `
                <div class="teacher-panel fade-in">
                    <h2>👨‍🏫 Öğretmen Paneli - Site Tasarımcısı</h2>
                    <p>Hoş geldiniz, ${studentInfo.fullName}</p>
                    
                    <div class="teacher-tabs">
                        <button class="teacher-tab active" onclick="showTeacherTab('students')">📊 Öğrenciler</button>
                        <button class="teacher-tab" onclick="showTeacherTab('content')">📝 İçerik Düzenle</button>
                        <button class="teacher-tab" onclick="showTeacherTab('wortschatz')">📚 Wortschatz Editörü</button>
                        <button class="teacher-tab" onclick="showTeacherTab('certificates')">🎓 Sertifikalar</button>
                        <button class="teacher-tab" onclick="showTeacherTab('settings')">⚙️ Ayarlar</button>
                    </div>
                    
                    <div id="teacherContent"></div>
                </div>
            `;
            
            showTeacherTab('students');
        }

        async function showTeacherTab(tab) {
            const content = document.getElementById('teacherContent');
            const tabs = document.querySelectorAll('.teacher-tab');
            tabs.forEach(t => t.classList.remove('active'));
            event.target.classList.add('active');
            
            if (tab === 'students') {
                content.innerHTML = '<div class="loading">Öğrenciler yükleniyor</div>';
                
                try {
                    const snapshot = await db.collection('students').get();
                    const students = [];
                    snapshot.forEach(doc => students.push({ id: doc.id, ...doc.data() }));
                    
                    content.innerHTML = `
                        <div class="unit-detail">
                            <h3>Öğrenci Listesi (${students.length} öğrenci)</h3>
                            <table class="leaderboard-table">
                                <thead>
                                    <tr>
                                        <th>Ad Soyad</th>
                                        <th>Sınıf</th>
                                        <th>Puan</th>
                                        <th>Ünite</th>
                                        <th>İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${students.map(s => `
                                        <tr>
                                            <td>${s.fullName}</td>
                                            <td>${s.class}</td>
                                            <td>${s.totalPoints || 0}</td>
                                            <td>${(s.completedUnits || []).length}/8</td>
                                            <td>
                                                <button class="btn btn-primary" onclick="resetStudentProgress('${s.id}')">İlerlemeyi Sıfırla</button>
                                                <button class="btn btn-primary" onclick="deleteStudentCompletely('${s.id}', '${s.fullName}')" style="background: linear-gradient(135deg, #E74C3C, #C0392B); margin-left: 0.5rem;">
                                                    Tamamen Sil
                                                </button>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    `;
                } catch (error) {
                    content.innerHTML = `<div class="dialogue-box">❌ Hata: ${error.message}</div>`;
                }
            } else if (tab === 'content') {
                content.innerHTML = `
                    <div class="unit-detail">
                        <h3>🎨 Site İçerik Yönetimi</h3>
                        <p>Tüm ünite içeriklerini buradan düzenleyebilirsiniz.</p>
                        <div class="form-group">
                            <label>Themenkreis Seç:</label>
                            <select class="input-field" id="unitSelectTeacher" onchange="loadUnitForEdit(this.value)">
                                <option value="">Seçiniz...</option>
                                ${Object.keys(unitsData).map(u => `<option value="${u}">Themenkreis ${u} - ${unitsData[u].title}</option>`).join('')}
                            </select>
                        </div>
                        <div id="unitEditArea"></div>
                    </div>
                `;
            } else if (tab === 'wortschatz') {
                content.innerHTML = `
                    <div class="unit-detail">
                        <h3>📚 Wortschatz Editörü (Sınırsız Kart)</h3>
                        <p>Her ünite için kelime kartlarını düzenleyin, ekleyin veya silin.</p>
                        <div class="form-group">
                            <label>Themenkreis Seç:</label>
                            <select class="input-field" id="vocabUnitSelect" onchange="loadWortschatzEditor(this.value)">
                                <option value="">Seçiniz...</option>
                                ${Object.keys(unitsData).map(u => `<option value="${u}">Themenkreis ${u} - ${unitsData[u].title}</option>`).join('')}
                            </select>
                        </div>
                        <div id="wortschatzEditArea"></div>
                    </div>
                `;
            } else if (tab === 'certificates') {
                content.innerHTML = '<div class="loading">Sertifikalar yükleniyor</div>';
                
                try {
                    const snapshot = await db.collection('students')
                        .where('completedUnits', '!=', [])
                        .get();
                    const eligibleStudents = [];
                    snapshot.forEach(doc => {
                        const data = doc.data();
                        const avgScore = (data.completedUnits || []).length > 0 
                            ? Object.values(data.testScores || {}).reduce((a, b) => a + b, 0) / (data.completedUnits || []).length
                            : 0;
                        if ((data.completedUnits || []).length === 8 && avgScore >= 60) {
                            eligibleStudents.push({ id: doc.id, ...data, avgScore: Math.round(avgScore) });
                        }
                    });
                    
                    content.innerHTML = `
                        <div class="unit-detail">
                            <h3>Sertifika Yönetimi (${eligibleStudents.length} sertifika)</h3>
                            ${eligibleStudents.length > 0 ? `
                                <table class="leaderboard-table">
                                    <thead>
                                        <tr>
                                            <th>Ad Soyad</th>
                                            <th>Sınıf</th>
                                            <th>Başarı %</th>
                                            <th>Tarih</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${eligibleStudents.map(s => `
                                            <tr>
                                                <td>${s.fullName}</td>
                                                <td>${s.class}</td>
                                                <td>${s.avgScore}%</td>
                                                <td>${new Date(s.createdAt).toLocaleDateString('tr-TR')}</td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            ` : '<p>Henüz sertifika almaya uygun öğrenci yok.</p>'}
                        </div>
                    `;
                } catch (error) {
                    content.innerHTML = `<div class="dialogue-box">❌ Hata: ${error.message}</div>`;
                }
            } else if (tab === 'settings') {
                content.innerHTML = `
                    <div class="unit-detail">
                        <h3>⚙️ Site Ayarları</h3>
                        <div class="form-group">
                            <label>Dark Mode:</label>
                            <button class="btn btn-dark" onclick="toggleDarkMode()">Değiştir</button>
                        </div>
                        <div class="form-group">
                            <label>Test Soru Sayısı:</label>
                            <input type="number" class="input-field" value="10" disabled>
                        </div>
                        <button class="btn btn-secondary" onclick="alert('Ayarlar kaydedildi!')">
                            Kaydet
                        </button>
                    </div>
                `;
            }
        }

        async function resetStudentProgress(studentId) {
            if (!isTeacher) {
                alert('❌ Bu özellik sadece öğretmenler içindir!');
                return;
            }
            
            if (!confirm('Bu öğrencinin tüm ilerlemesini sıfırlamak istediğinizden emin misiniz?')) return;
            
            try {
                await db.collection('students').doc(studentId).update({
                    completedUnits: [],
                    totalPoints: 0,
                    averageScore: 0,
                    testScores: {},
                    exerciseScores: {},
                    lastUpdated: firebase.firestore.FieldValue.serverTimestamp()
                });
                alert('✅ Öğrenci ilerlemesi sıfırlandı!');
                
                // Refresh the list
                showTeacherPanel();
                setTimeout(() => {
                    const studentsTab = document.querySelector('.teacher-tab');
                    if (studentsTab) studentsTab.click();
                }, 300);
            } catch (error) {
                console.error('❌ Sıfırlama hatası:', error);
                alert('❌ Hata: ' + error.message + '\n\nFirestore kurallarınızı kontrol edin.');
            }
        }

        // Update breadcrumb
        function updateBreadcrumb() {
            const breadcrumb = document.getElementById('breadcrumb');
            let html = '<a onclick="showHome()">🏠 Ana Sayfa</a>';
            
            if (currentView === 'certificate') {
                html += ' &gt; <span>🎓 Sertifika</span>';
            } else if (currentView === 'leaderboard') {
                html += ' &gt; <span>🏆 Leaderboard</span>';
            } else if (currentView === 'profile') {
                html += ' &gt; <span>👤 Profil</span>';
            } else if (currentView === 'teacher') {
                html += ' &gt; <span>👨‍🏫 Öğretmen Paneli</span>';
            } else if (currentUnit) {
                const unit = unitsData[currentUnit];
                html += ` &gt; <a onclick="showUnit(${currentUnit})">Themenkreis ${currentUnit}</a>`;
                if (currentSection) {
                    const names = {
                        kommunikation: 'Kommunikation',
                        wortschatz: 'Wortschatz',
                        grammatik: 'Grammatik',
                        ubungen: 'Übungen',
                        test: 'Test'
                    };
                    html += ` &gt; <span>${names[currentSection]}</span>`;
                }
            }
            
            breadcrumb.innerHTML = html;
        }

        // Update global progress
        function updateGlobalProgress() {
            const totalUnits = Object.keys(unitsData).length;
            const completedTests = Object.keys(testScores).filter(key => testScores[key] > 0).length;
            const percentage = Math.round((completedTests / totalUnits) * 100);
            
            const progressFill = document.querySelector('.progress-fill');
            progressFill.style.width = percentage + '%';
            progressFill.textContent = percentage + '%';
        }

        // Toggle dark mode
        function toggleDarkMode() {
            darkMode = !darkMode;
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('darkMode', darkMode);
        }

        // Save progress
        function saveProgress() {
            localStorage.setItem('exerciseScores', JSON.stringify(exerciseScores));
            localStorage.setItem('testScores', JSON.stringify(testScores));
        }

        // Load progress
        function loadProgress() {
            const savedDarkMode = localStorage.getItem('darkMode');
            if (savedDarkMode === 'true') {
                darkMode = true;
                document.body.classList.add('dark-mode');
            }
            
            const savedExerciseScores = localStorage.getItem('exerciseScores');
            if (savedExerciseScores) {
                exerciseScores = JSON.parse(savedExerciseScores);
            }
            
            const savedTestScores = localStorage.getItem('testScores');
            if (savedTestScores) {
                testScores = JSON.parse(savedTestScores);
            }
        }

        // Reset progress
        function resetProgress() {
            if (confirm('Tüm ilerlemeyi silmek istediğinizden emin misiniz?')) {
                localStorage.removeItem('exerciseScores');
                localStorage.removeItem('testScores');
                exerciseScores = {};
                testScores = {};
                updateGlobalProgress();
                checkCertificateEligibility();
                if (studentDocId && db) {
                    updateStudentInFirestore();
                }
                alert('✅ İlerleme sıfırlandı!');
                showHome();
            }
        }

        // Delete student account completely
        async function deleteMyAccount() {
            if (!confirm('⚠️ UYARI: Hesabınız ve tüm verileriniz kalıcı olarak silinecek!\n\nDevam etmek istediğinizden emin misiniz?')) {
                return;
            }
            
            if (!confirm('Bu işlem geri alınamaz! Son kez soruyoruz, hesabınızı silmek istediğinizden EMİN MİSİNİZ?')) {
                return;
            }
            
            try {
                // Delete from Firestore
                if (studentDocId && db) {
                    await db.collection('students').doc(studentDocId).delete();
                    console.log('✅ Firestore kaydı silindi');
                }
                
                // Clear localStorage
                localStorage.clear();
                
                // Reset state
                studentInfo = null;
                studentDocId = null;
                exerciseScores = {};
                testScores = {};
                
                alert('✅ Hesabınız başarıyla silindi!');
                
                // Reload page to show login modal
                window.location.reload();
            } catch (error) {
                console.error('❌ Hesap silme hatası:', error);
                alert('❌ Hata: ' + error.message);
            }
        }

        // Delete student from teacher panel (complete deletion)
        async function deleteStudentCompletely(studentId, studentName) {
            if (!confirm(`⚠️ ${studentName} isimli öğrenciyi Leaderboard'dan tamamen kaldırmak istediğinizden emin misiniz?\n\nBu işlem geri alınamaz!`)) {
                return;
            }
            
            try {
                await db.collection('students').doc(studentId).delete();
                alert('✅ Öğrenci tamamen silindi!');
                showTeacherTab('students');
            } catch (error) {
                alert('❌ Hata: ' + error.message);
            }
        }

        // Enhanced badge system with modal
        function showBadgeModal(badge) {
            const modal = document.createElement('div');
            modal.innerHTML = `
                <div class="badge-modal-overlay" onclick="this.parentElement.remove()"></div>
                <div class="badge-modal">
                    <div class="badge-modal-icon">${badge.icon}</div>
                    <h3>${badge.title}</h3>
                    <p style="font-size: 1.1rem; line-height: 1.8; color: var(--text-secondary);">
                        ${badge.description}
                    </p>
                    <p style="margin-top: 1rem; font-weight: 600; color: ${badge.unlocked ? 'var(--success)' : 'var(--error)'};">
                        ${badge.unlocked ? '✅ KAZANILDI' : '🔒 KİLİTLİ'}
                    </p>
                    <button class="btn btn-secondary" onclick="this.closest('div').parentElement.remove()" style="width: 100%; margin-top: 1rem;">
                        Kapat
                    </button>
                </div>
            `;
            document.body.appendChild(modal);
        }

        // Calculate badges - ENHANCED with 12 badges
        function calculateBadges(completedUnits, avgScore, totalPoints) {
            return [
                { 
                    icon: '🌟', 
                    title: 'İlk Adım', 
                    unlocked: completedUnits >= 1,
                    description: 'İlk ünitenizi tamamladınız! Almanca öğrenme yolculuğunuza başladınız.'
                },
                { 
                    icon: '🔥', 
                    title: 'Azimli', 
                    unlocked: completedUnits >= 4,
                    description: '4 üniteyi tamamladınız! Kararlılığınız takdire şayan.'
                },
                { 
                    icon: '🏆', 
                    title: 'Şampiyon', 
                    unlocked: completedUnits === 8,
                    description: 'Tüm üniteleri tamamladınız! Gerçek bir şampiyonsunuz!'
                },
                { 
                    icon: '💯', 
                    title: 'Mükemmeliyetçi', 
                    unlocked: avgScore === 100,
                    description: '%100 başarı! Kusursuz performans gösterdiniz.'
                },
                { 
                    icon: '⭐', 
                    title: 'Yıldız', 
                    unlocked: avgScore >= 80,
                    description: '%80 ve üzeri başarı! Parlak bir öğrencisiniz.'
                },
                { 
                    icon: '📚', 
                    title: 'Bilge', 
                    unlocked: totalPoints >= 100,
                    description: '100+ puan! Bilgi dağarcığınız çok geniş.'
                },
                { 
                    icon: '🎯', 
                    title: 'Hedef Odaklı', 
                    unlocked: completedUnits >= 6,
                    description: '6 ünite tamamlandı! Hedefinize yaklaştınız.'
                },
                { 
                    icon: '💪', 
                    title: 'Güçlü', 
                    unlocked: totalPoints >= 50,
                    description: '50+ puan! İradeniz çok güçlü.'
                },
                { 
                    icon: '🚀', 
                    title: 'Hızlı Öğrenen', 
                    unlocked: completedUnits >= 3 && avgScore >= 75,
                    description: '3 ünite ve %75+ başarı! Hızlı öğreniyorsunuz.'
                },
                { 
                    icon: '🎓', 
                    title: 'Akademisyen', 
                    unlocked: avgScore >= 90 && completedUnits >= 5,
                    description: '%90+ başarı ve 5+ ünite! Akademik başarı.'
                },
                { 
                    icon: '🤖', 
                    title: 'Çok Yönlü', 
                    unlocked: totalPoints >= 150,
                    description: '150+ puan! Her konuda yeteneklisiniz.'
                },
                { 
                    icon: '👑', 
                    title: 'BABAPİRO', 
                    unlocked: completedUnits === 8 && avgScore >= 95,
                    description: 'Tüm üniteler %95+ ile! Kraliyet performansı!'
                }
            ];
        }

        // Load unit for editing in teacher panel - FULL DESIGNER MODE
        function loadUnitForEdit(unitNum) {
            if (!unitNum) return;
            
            const unit = unitsData[unitNum];
            const editArea = document.getElementById('unitEditArea');
            
            editArea.innerHTML = `
                <div class="unit-detail" style="margin-top: 2rem;">
                    <h3>🎨 Themenkreis ${unitNum}: ${unit.title} - Tam Düzenleme</h3>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                        <div class="form-group">
                            <label>📝 Almanca Başlık:</label>
                            <input type="text" class="input-field" id="edit_title" value="${unit.title}">
                        </div>
                        
                        <div class="form-group">
                            <label>🇹🇷 Türkçe Alt Başlık:</label>
                            <input type="text" class="input-field" id="edit_subtitle" value="${unit.subtitle}">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>🎨 Tema Rengi:</label>
                        <input type="color" class="input-field" id="edit_color" value="${unit.color}" style="height: 50px; width: 100px;">
                    </div>
                    
                    <hr style="margin: 2rem 0; border-color: rgba(255,255,255,0.2);">
                    
                    <h4>🗣️ Kommunikation - Öğrenme Hedefleri</h4>
                    <div class="form-group">
                        <textarea class="input-field" id="edit_skills" rows="5">${unit.kommunikation.skills.join('\n')}</textarea>
                        <small>Her satıra bir beceri yazın</small>
                    </div>
                    
                    <h4>💬 Örnek Cümleler</h4>
                    <div class="form-group">
                        <textarea class="input-field" id="edit_examples" rows="5">${unit.kommunikation.examples.join('\n')}</textarea>
                        <small>Her satıra bir örnek cümle yazın</small>
                    </div>
                    
                    <h4>🎭 Diyaloglar</h4>
                    <div id="dialogueEditList">
                        ${unit.kommunikation.dialogues.map((d, idx) => `
                            <div class="dialogue-box" style="margin: 0.5rem 0; display: grid; grid-template-columns: 150px 1fr auto; gap: 0.5rem; align-items: center;">
                                <input type="text" class="input-field" value="${d.speaker}" id="dialogue_speaker_${idx}" placeholder="Konuşan">
                                <input type="text" class="input-field" value="${d.text}" id="dialogue_text_${idx}" placeholder="Metin">
                                <button class="btn btn-secondary" onclick="removeDialogue(${idx})" style="padding: 0.5rem;">❌</button>
                            </div>
                        `).join('')}
                    </div>
                    <button class="btn btn-secondary" onclick="addNewDialogue()" style="margin-top: 0.5rem;">
                        ➕ Yeni Diyalog Ekle
                    </button>
                    
                    <hr style="margin: 2rem 0; border-color: rgba(255,255,255,0.2);">
                    
                    <h4>📖 Grammatik Konuları</h4>
                    <div id="grammarEditList">
                        ${unit.grammatik.map((g, idx) => `
                            <div class="dialogue-box" style="margin: 1rem 0; padding: 1rem;">
                                <div class="form-group">
                                    <label>Konu ${idx + 1}:</label>
                                    <input type="text" class="input-field" value="${g.topic}" id="grammar_topic_${idx}">
                                </div>
                                <div class="form-group">
                                    <label>Açıklama:</label>
                                    <textarea class="input-field" id="grammar_explanation_${idx}" rows="2">${g.explanation}</textarea>
                                </div>
                                <div class="form-group">
                                    <label>Örnek:</label>
                                    <input type="text" class="input-field" value="${g.example}" id="grammar_example_${idx}">
                                </div>
                            </div>
                        `).join('')}
                    </div>
                    
                    <hr style="margin: 2rem 0; border-color: rgba(255,255,255,0.2);">
                    
                    <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                        <button class="btn btn-primary" onclick="saveUnitChangesToFirestore(${unitNum})" style="font-size: 1.2rem; flex: 1;">
                            💾 Firestore'a Kaydet ve Yayınla
                        </button>
                        <button class="btn btn-secondary" onclick="loadUnitForEdit(${unitNum})" style="flex: 0 0 auto;">
                            🔄 Sıfırla
                        </button>
                    </div>
                    
                    <p style="margin-top: 1rem; font-size: 0.9rem; color: white; text-align: center;">
                        ℹ️ Değişiklikler Firestore'a kaydedilir ve TÜM kullanıcılara ANINDA yansır.
                    </p>
                </div>
            `;
        }

        // Wortschatz Editor - Unlimited Cards
        function loadWortschatzEditor(unitNum) {
            if (!unitNum) return;
            
            const unit = unitsData[unitNum];
            const editArea = document.getElementById('wortschatzEditArea');
            
            editArea.innerHTML = `
                <div class="unit-detail" style="margin-top: 2rem;">
                    <h3>📚 Themenkreis ${unitNum} - Wortschatz Editörü</h3>
                    <p>Toplam <strong>${unit.wortschatz.length}</strong> kelime kartı</p>
                    
                    <div id="vocabCardsList" style="max-height: 500px; overflow-y: auto; padding: 1rem; background: rgba(0,0,0,0.2); border-radius: 10px;">
                        ${unit.wortschatz.map((w, idx) => `
                            <div class="vocab-edit-row" id="vocabRow_${idx}" style="display: grid; grid-template-columns: 40px 1fr 1fr auto; gap: 0.5rem; margin-bottom: 0.5rem; align-items: center;">
                                <span style="color: var(--text-secondary); text-align: center;">${idx + 1}</span>
                                <input type="text" class="input-field vocab-de" value="${w.word}" placeholder="Almanca">
                                <input type="text" class="input-field vocab-tr" value="${w.tr}" placeholder="Türkçe">
                                <button class="btn btn-secondary" onclick="removeVocabCard(${unitNum}, ${idx})" style="padding: 0.5rem; background: linear-gradient(135deg, #E74C3C, #C0392B);">❌</button>
                            </div>
                        `).join('')}
                    </div>
                    
                    <div style="margin-top: 1.5rem; display: flex; gap: 1rem; flex-wrap: wrap;">
                        <button class="btn btn-secondary" onclick="addNewVocabCard(${unitNum})" style="flex: 1;">
                            ➕ Yeni Kelime Kartı Ekle
                        </button>
                        <button class="btn btn-secondary" onclick="addMultipleVocabCards(${unitNum})" style="flex: 1;">
                            ➕➕ Toplu Ekle (5 kart)
                        </button>
                    </div>
                    
                    <button class="btn btn-primary" onclick="saveWortschatzToFirestore(${unitNum})" style="width: 100%; margin-top: 2rem; font-size: 1.2rem;">
                        💾 Wortschatz'ı Kaydet
                    </button>
                </div>
            `;
        }

        // Add new vocab card
        function addNewVocabCard(unitNum) {
            const unit = unitsData[unitNum];
            const newIdx = unit.wortschatz.length;
            
            // Add empty card to data
            unit.wortschatz.push({ word: '', tr: '', category: '' });
            
            // Add to UI
            const list = document.getElementById('vocabCardsList');
            const newRow = document.createElement('div');
            newRow.className = 'vocab-edit-row';
            newRow.id = `vocabRow_${newIdx}`;
            newRow.style.cssText = 'display: grid; grid-template-columns: 40px 1fr 1fr auto; gap: 0.5rem; margin-bottom: 0.5rem; align-items: center;';
            newRow.innerHTML = `
                <span style="color: var(--text-secondary); text-align: center;">${newIdx + 1}</span>
                <input type="text" class="input-field vocab-de" value="" placeholder="Almanca">
                <input type="text" class="input-field vocab-tr" value="" placeholder="Türkçe">
                <button class="btn btn-secondary" onclick="removeVocabCard(${unitNum}, ${newIdx})" style="padding: 0.5rem; background: linear-gradient(135deg, #E74C3C, #C0392B);">❌</button>
            `;
            list.appendChild(newRow);
            
            // Scroll to new card
            list.scrollTop = list.scrollHeight;
            
            // Focus on new input
            newRow.querySelector('.vocab-de').focus();
        }

        // Add multiple vocab cards
        function addMultipleVocabCards(unitNum) {
            for (let i = 0; i < 5; i++) {
                addNewVocabCard(unitNum);
            }
        }

        // Remove vocab card
        function removeVocabCard(unitNum, idx) {
            if (!confirm('Bu kelime kartını silmek istediğinizden emin misiniz?')) return;
            
            const unit = unitsData[unitNum];
            unit.wortschatz.splice(idx, 1);
            
            // Reload the editor
            loadWortschatzEditor(unitNum);
        }

        // Save Wortschatz to Firestore
        async function saveWortschatzToFirestore(unitNum) {
            if (!db) {
                alert('❌ Firebase bağlantısı yok!');
                return;
            }
            
            try {
                const rows = document.querySelectorAll('.vocab-edit-row');
                const newVocab = [];
                
                rows.forEach((row, idx) => {
                    const deInput = row.querySelector('.vocab-de');
                    const trInput = row.querySelector('.vocab-tr');
                    
                    if (deInput && trInput && deInput.value.trim()) {
                        newVocab.push({
                            word: deInput.value.trim(),
                            tr: trInput.value.trim(),
                            category: ''
                        });
                    }
                });
                
                // Update local data
                unitsData[unitNum].wortschatz = newVocab;
                
                // Save to Firestore
                const contentDoc = db.collection('content').doc('units');
                await contentDoc.set({
                    [unitNum]: {
                        wortschatz: newVocab,
                        lastUpdated: new Date().toISOString(),
                        updatedBy: studentInfo ? studentInfo.fullName : 'unknown'
                    }
                }, { merge: true });
                
                alert(`✅ Wortschatz kaydedildi! (${newVocab.length} kelime)`);
                
                // Reset flashcard state for this unit
                if (window.flashcardState && window.flashcardState[unitNum]) {
                    window.flashcardState[unitNum].index = 0;
                    window.flashcardState[unitNum].flipped = false;
                }
                
            } catch (error) {
                console.error('❌ Kaydetme hatası:', error);
                alert('❌ Hata: ' + error.message);
            }
        }

        // Add new dialogue
        function addNewDialogue() {
            const list = document.getElementById('dialogueEditList');
            const idx = list.children.length;
            
            const newRow = document.createElement('div');
            newRow.className = 'dialogue-box';
            newRow.style.cssText = 'margin: 0.5rem 0; display: grid; grid-template-columns: 150px 1fr auto; gap: 0.5rem; align-items: center;';
            newRow.innerHTML = `
                <input type="text" class="input-field" value="" id="dialogue_speaker_${idx}" placeholder="Konuşan">
                <input type="text" class="input-field" value="" id="dialogue_text_${idx}" placeholder="Metin">
                <button class="btn btn-secondary" onclick="this.parentElement.remove()" style="padding: 0.5rem;">❌</button>
            `;
            list.appendChild(newRow);
            newRow.querySelector('input').focus();
        }

        // Remove dialogue
        function removeDialogue(idx) {
            const row = document.getElementById(`dialogue_speaker_${idx}`).parentElement;
            row.remove();
        }

        // Save unit changes to Firestore - FIXED: No nested arrays
        async function saveUnitChangesToFirestore(unitNum) {
            if (!db) {
                alert('❌ Firebase bağlantısı yok!');
                return;
            }
            
            if (!isTeacher) {
                alert('❌ Bu özellik sadece öğretmenler içindir!');
                return;
            }
            
            try {
                // Show loading state
                const saveBtn = event.target;
                const originalText = saveBtn.textContent;
                saveBtn.textContent = '⏳ Kaydediliyor...';
                saveBtn.disabled = true;
                
                // Collect all changes from form
                const title = document.getElementById('edit_title').value;
                const subtitle = document.getElementById('edit_subtitle').value;
                const color = document.getElementById('edit_color').value;
                const skills = document.getElementById('edit_skills').value.split('\n').filter(s => s.trim());
                const examples = document.getElementById('edit_examples').value.split('\n').filter(e => e.trim());
                
                // Collect vocabulary changes
                const updatedVocab = [];
                for (let i = 0; i < 10; i++) {
                    const deEl = document.getElementById(`vocab_de_${i}`);
                    const trEl = document.getElementById(`vocab_tr_${i}`);
                    const catEl = document.getElementById(`vocab_cat_${i}`);
                    
                    if (deEl && trEl && catEl && deEl.value.trim()) {
                        updatedVocab.push({
                            word: deEl.value.trim(),
                            tr: trEl.value.trim(),
                            category: catEl.value.trim()
                        });
                    }
                }
                
                // Keep rest of the vocabulary unchanged
                const restVocab = unitsData[unitNum].wortschatz.slice(10);
                const allVocab = [...updatedVocab, ...restVocab];
                
                // Update local data first
                unitsData[unitNum].title = title;
                unitsData[unitNum].subtitle = subtitle;
                unitsData[unitNum].color = color;
                unitsData[unitNum].kommunikation.skills = skills;
                unitsData[unitNum].kommunikation.examples = examples;
                unitsData[unitNum].wortschatz = allVocab;
                
                // Prepare Firestore-safe data (NO NESTED ARRAYS)
                const firestoreData = {
                    title: title,
                    subtitle: subtitle,
                    color: color,
                    kommunikation: {
                        skills: skills,
                        examples: examples,
                        // Convert dialogues to safe format
                        dialogues: convertDialoguesForFirestore(unitsData[unitNum].kommunikation.dialogues),
                        prompt: unitsData[unitNum].kommunikation.prompt || ''
                    },
                    // Vocabulary is already array of objects - safe
                    wortschatz: allVocab,
                    // Convert grammatik tables to safe format
                    grammatik: convertGrammatikForFirestore(unitsData[unitNum].grammatik),
                    // Metadata
                    lastUpdated: new Date().toISOString(),
                    updatedBy: studentInfo ? studentInfo.fullName : 'unknown'
                };
                
                console.log('📤 Firestore\'a kaydedilen veri:', firestoreData);
                
                // Save to Firestore with merge
                const contentDoc = db.collection('content').doc('units');
                await contentDoc.set({
                    [unitNum]: firestoreData
                }, { merge: true });
                
                console.log('✅ Firestore kaydı başarılı!');
                
                // Restore button
                saveBtn.textContent = '✅ Kaydedildi!';
                setTimeout(() => {
                    saveBtn.textContent = originalText;
                    saveBtn.disabled = false;
                }, 2000);
                
                alert('✅ Değişiklikler başarıyla Firestore\'a kaydedildi!\n\nTüm kullanıcılar anlık olarak güncellenecektir.');
                
                // Reload the unit to show changes
                showUnit(unitNum);
                
            } catch (error) {
                console.error('❌ Kaydetme hatası:', error);
                console.error('Hata detayı:', error.message);
                
                // Restore button on error
                if (event && event.target) {
                    event.target.textContent = '💾 Firestore\'a Kaydet ve Yayınla';
                    event.target.disabled = false;
                }
                
                alert('❌ Kaydetme hatası!\n\n' + error.message + '\n\nLütfen tekrar deneyin.');
            }
        }

        // Enhanced Übungen with different exercise types
        function renderEnhancedExercises(content) {
            const unit = unitsData[currentUnit];
            let score = exerciseScores[currentUnit] || 0;
            
            const exerciseTypes = [
                {
                    type: 'multiple',
                    title: 'Çoktan Seçmeli / Multiple Choice',
                    icon: '📝'
                },
                {
                    type: 'fillblank',
                    title: 'Boşluk Doldurma / Fill in the Blank',
                    icon: '✍️'
                },
                {
                    type: 'matching',
                    title: 'Eşleştirme / Matching',
                    icon: '🔗'
                },
                {
                    type: 'truefalse',
                    title: 'Doğru-Yanlış / True-False',
                    icon: '✓✗'
                }
            ];
            
            content.innerHTML = `
                <h2>✏️ Übungen / Alıştırmalar</h2>
                <div class="score-display" id="exerciseScore">Puan / Points: ${score}</div>
                
                ${exerciseTypes.map(et => `
                    <div class="unit-detail" style="margin: 2rem 0;">
                        <h3>${et.icon} ${et.title}</h3>
                        <div id="${et.type}Container"></div>
                    </div>
                `).join('')}
            `;
            
            // Generate different exercise types
            generateMultipleChoiceEx();
            generateFillBlankEx();
            generateMatchingEx();
            generateTrueFalseEx();
        }

        function generateMultipleChoiceEx() {
            const unit = unitsData[currentUnit];
            const container = document.getElementById('multipleContainer');
            const vocab = unit.wortschatz.slice(0, 3);
            
            let html = '';
            vocab.forEach((word, idx) => {
                const wrong = unit.wortschatz.filter(w => w.word !== word.word).sort(() => 0.5 - Math.random()).slice(0, 3);
                const options = [word.tr, ...wrong.map(w => w.tr)].sort(() => 0.5 - Math.random());
                
                html += `
                    <div class="exercise-container">
                        <div class="exercise-question">${idx + 1}. "${word.word}" ne anlama gelir?</div>
                        <div class="exercise-options">
                            ${options.map((opt, optIdx) => `
                                <button class="option-btn" onclick="checkExAnswer('multi${idx}', ${optIdx}, ${options.indexOf(word.tr)})" 
                                        id="multi${idx}-${optIdx}">${opt}</button>
                            `).join('')}
                        </div>
                    </div>
                `;
            });
            container.innerHTML = html;
        }

        function generateFillBlankEx() {
            const unit = unitsData[currentUnit];
            const container = document.getElementById('fillblankContainer');
            const examples = unit.kommunikation.examples.slice(0, 2);
            
            let html = '';
            examples.forEach((ex, idx) => {
                const words = ex.split(' ');
                const blankIdx = Math.min(2, Math.floor(Math.random() * words.length));
                const correctWord = words[blankIdx];
                words[blankIdx] = '______';
                
                html += `
                    <div class="exercise-container">
                        <div class="exercise-question">${idx + 1}. ${words.join(' ')}</div>
                        <input type="text" class="input-field" id="fill${idx}" placeholder="Boş yere yazın...">
                        <button class="btn btn-primary" onclick="checkFillBlank(${idx}, '${correctWord.toLowerCase()}')">
                            Kontrol Et
                        </button>
                        <div id="fill${idx}Result"></div>
                    </div>
                `;
            });
            container.innerHTML = html;
        }

        function generateMatchingEx() {
            const container = document.getElementById('matchingContainer');
            const unit = unitsData[currentUnit];
            const vocab = unit.wortschatz.slice(0, 4);
            
            const leftSide = vocab.map(v => v.word).sort(() => 0.5 - Math.random());
            const rightSide = vocab.map(v => ({ word: v.word, tr: v.tr })).sort(() => 0.5 - Math.random());
            
            container.innerHTML = `
                <div class="match-container">
                    <div>
                        <h4>Almanca</h4>
                        ${leftSide.map((w, idx) => `
                            <div class="match-item" onclick="selectMatch('left', ${idx}, '${w}')" id="leftMatch${idx}">
                                ${w}
                            </div>
                        `).join('')}
                    </div>
                    <div>
                        <h4>Türkçe</h4>
                        ${rightSide.map((w, idx) => `
                            <div class="match-item" onclick="selectMatch('right', ${idx}, '${w.word}')" id="rightMatch${idx}">
                                ${w.tr}
                            </div>
                        `).join('')}
                    </div>
                </div>
                <div id="matchResult" style="text-align: center; margin-top: 1rem;"></div>
            `;
        }

        let matchSelection = { left: null, right: null, leftWord: null, rightWord: null };

        function selectMatch(side, idx, word) {
            // Deselect previous
            document.querySelectorAll('.match-item.selected').forEach(el => {
                if (!el.classList.contains('matched')) {
                    el.classList.remove('selected');
                }
            });
            
            const el = document.getElementById(`${side}Match${idx}`);
            if (el.classList.contains('matched')) return;
            
            el.classList.add('selected');
            matchSelection[side] = idx;
            matchSelection[side + 'Word'] = word;
            
            if (matchSelection.left !== null && matchSelection.right !== null) {
                if (matchSelection.leftWord === matchSelection.rightWord) {
                    document.getElementById(`leftMatch${matchSelection.left}`).classList.add('matched');
                    document.getElementById(`rightMatch${matchSelection.right}`).classList.add('matched');
                    document.getElementById('matchResult').innerHTML = '<p style="color: var(--success); font-weight: bold;">✅ Doğru eşleştirme!</p>';
                    
                    exerciseScores[currentUnit] = (exerciseScores[currentUnit] || 0) + 1;
                    updateExerciseScore();
                } else {
                    document.getElementById('matchResult').innerHTML = '<p style="color: var(--error); font-weight: bold;">❌ Yanlış eşleştirme, tekrar deneyin!</p>';
                    setTimeout(() => {
                        document.querySelectorAll('.match-item.selected:not(.matched)').forEach(el => el.classList.remove('selected'));
                    }, 1000);
                }
                
                matchSelection = { left: null, right: null, leftWord: null, rightWord: null };
            }
        }

        function generateTrueFalseEx() {
            const container = document.getElementById('truefalseContainer');
            const unit = unitsData[currentUnit];
            
            const statements = [
                { text: `"${unit.wortschatz[0].word}" kelimesi "${unit.wortschatz[0].tr}" anlamına gelir.`, correct: true },
                { text: `"${unit.wortschatz[1].word}" kelimesi "${unit.wortschatz[2].tr}" anlamına gelir.`, correct: false }
            ];
            
            container.innerHTML = statements.map((stmt, idx) => `
                <div class="exercise-container">
                    <div class="exercise-question">${idx + 1}. ${stmt.text}</div>
                    <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                        <button class="option-btn" onclick="checkTrueFalse(${idx}, true, ${stmt.correct})" id="tf${idx}True">
                            ✓ Doğru / Richtig
                        </button>
                        <button class="option-btn" onclick="checkTrueFalse(${idx}, false, ${stmt.correct})" id="tf${idx}False">
                            ✗ Yanlış / Falsch
                        </button>
                    </div>
                </div>
            `).join('');
        }

        function checkExAnswer(id, selected, correct) {
            const buttons = document.querySelectorAll(`[id^="${id}-"]`);
            buttons.forEach((btn, idx) => {
                btn.disabled = true;
                if (idx === correct) {
                    btn.classList.add('correct');
                } else if (idx === selected) {
                    btn.classList.add('wrong');
                }
            });
            
            if (selected === correct) {
                exerciseScores[currentUnit] = (exerciseScores[currentUnit] || 0) + 1;
                updateExerciseScore();
            }
        }

        function checkFillBlank(idx, correct) {
            const input = document.getElementById(`fill${idx}`);
            const result = document.getElementById(`fill${idx}Result`);
            const answer = input.value.toLowerCase().trim();
            
            if (answer === correct) {
                result.innerHTML = '<p style="color: var(--success); font-weight: bold; margin-top: 1rem;">✅ Doğru!</p>';
                exerciseScores[currentUnit] = (exerciseScores[currentUnit] || 0) + 1;
                updateExerciseScore();
                input.disabled = true;
            } else {
                result.innerHTML = '<p style="color: var(--error); font-weight: bold; margin-top: 1rem;">❌ Yanlış, tekrar deneyin!</p>';
            }
        }

        function checkTrueFalse(idx, answer, correct) {
            const trueBtn = document.getElementById(`tf${idx}True`);
            const falseBtn = document.getElementById(`tf${idx}False`);
            
            trueBtn.disabled = true;
            falseBtn.disabled = true;
            
            if (answer === correct) {
                (answer ? trueBtn : falseBtn).classList.add('correct');
                exerciseScores[currentUnit] = (exerciseScores[currentUnit] || 0) + 1;
                updateExerciseScore();
            } else {
                (answer ? trueBtn : falseBtn).classList.add('wrong');
                (!answer ? trueBtn : falseBtn).classList.add('correct');
            }
        }

        function updateExerciseScore() {
            const scoreEl = document.getElementById('exerciseScore');
            if (scoreEl) {
                scoreEl.textContent = `Puan / Points: ${exerciseScores[currentUnit] || 0}`;
            }
            saveProgress();
            updateStudentInFirestore();
        }

        // Initialize on load
        window.addEventListener('load', init);
